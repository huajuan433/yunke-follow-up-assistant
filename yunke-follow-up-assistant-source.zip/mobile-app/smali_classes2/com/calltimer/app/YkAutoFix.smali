.class public final Lcom/calltimer/app/YkAutoFix;
.super Ljava/lang/Object;
.source "YkAutoFix.java"


# static fields
.field private static final IME_ID:Ljava/lang/String; = "com.bytedance.android.doubaoime"

.field private static final PKG_SETTINGS:Ljava/lang/String; = "com.android.settings"

.field private static final PKG_YUNKE:Ljava/lang/String; = "com.yunke.enterprisep.miui"

.field private static final TAG:Ljava/lang/String; = "YkAutoFix"

.field private static sBackAt:J

.field private static sLastAgree:J

.field private static sLastCheck:J

.field private static sLastRepairClick:J

.field private static sRepairTries:I

.field private static sRepairing:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 27
    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/calltimer/app/YkAutoFix;->sLastAgree:J

    .line 28
    sput-wide v0, Lcom/calltimer/app/YkAutoFix;->sLastCheck:J

    .line 29
    sput-wide v0, Lcom/calltimer/app/YkAutoFix;->sLastRepairClick:J

    .line 30
    sput-wide v0, Lcom/calltimer/app/YkAutoFix;->sBackAt:J

    .line 31
    const/4 v0, 0x0

    sput-boolean v0, Lcom/calltimer/app/YkAutoFix;->sRepairing:Z

    .line 32
    sput v0, Lcom/calltimer/app/YkAutoFix;->sRepairTries:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    return-void
.end method

.method private static clickExactText(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;I)Z
    .locals 8

    .line 125
    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0, p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByText(Ljava/lang/String;)Ljava/util/List;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 128
    nop

    .line 129
    if-eqz p0, :cond_7

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_3

    .line 132
    :cond_0
    move v1, v0

    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_6

    .line 133
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 134
    if-nez v2, :cond_1

    .line 135
    goto :goto_2

    .line 137
    :cond_1
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    .line 138
    if-eqz v3, :cond_5

    invoke-virtual {p1, v3}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_2

    .line 139
    goto :goto_2

    .line 141
    :cond_2
    nop

    .line 142
    move v3, v0

    move-object v4, v2

    :goto_1
    const/16 v5, 0x10

    const/4 v6, 0x1

    if-gt v3, p2, :cond_4

    if-eqz v4, :cond_4

    .line 143
    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->isClickable()Z

    move-result v7

    if-eqz v7, :cond_3

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v7

    if-eqz v7, :cond_3

    .line 144
    invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    move-result v5

    if-eqz v5, :cond_3

    .line 145
    return v6

    .line 147
    :cond_3
    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getParent()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v4

    .line 142
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 149
    :cond_4
    invoke-virtual {v2, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    move-result v2

    if-eqz v2, :cond_5

    .line 150
    return v6

    .line 132
    :cond_5
    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 153
    :cond_6
    return v0

    .line 130
    :cond_7
    :goto_3
    return v0

    .line 126
    :catchall_0
    move-exception p0

    .line 127
    return v0
.end method

.method private static ensureIme(Landroid/content/Context;)V
    .locals 6

    .line 94
    const-string v0, "YkAutoFix"

    .line 95
    nop

    .line 97
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "enabled_input_methods"

    invoke-static {v1, v2}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 98
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "default_input_method"

    invoke-static {v2, v3}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 101
    nop

    .line 102
    const-string v3, "com.bytedance.android.doubaoime"

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    invoke-virtual {v1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    move v1, v5

    goto :goto_0

    :cond_0
    move v1, v4

    .line 103
    :goto_0
    if-eqz v2, :cond_1

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1

    move v4, v5

    .line 104
    :cond_1
    if-eqz v1, :cond_2

    if-eqz v4, :cond_2

    .line 105
    const/4 p0, 0x3

    sput p0, Lcom/calltimer/app/YkAutoFix;->sRepairTries:I

    .line 106
    return-void

    .line 108
    :cond_2
    if-nez v1, :cond_3

    .line 109
    sget v1, Lcom/calltimer/app/YkAutoFix;->sRepairTries:I

    add-int/2addr v1, v5

    sput v1, Lcom/calltimer/app/YkAutoFix;->sRepairTries:I

    .line 110
    sput-boolean v5, Lcom/calltimer/app/YkAutoFix;->sRepairing:Z

    .line 112
    :try_start_1
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.INPUT_METHOD_SETTINGS"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 113
    const/high16 v2, 0x10000000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 114
    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 115
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "open ime settings try="

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    sget v1, Lcom/calltimer/app/YkAutoFix;->sRepairTries:I

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 118
    goto :goto_1

    .line 116
    :catchall_0
    move-exception p0

    .line 117
    const-string v1, "open ime settings fail"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 120
    :cond_3
    :goto_1
    return-void

    .line 99
    :catchall_1
    move-exception p0

    .line 100
    return-void
.end method

.method public static handle(Landroid/accessibilityservice/AccessibilityService;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 13

    .line 38
    const-string v0, "YkAutoFix"

    if-nez p0, :cond_0

    .line 39
    return-void

    .line 42
    :cond_0
    :try_start_0
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    .line 43
    const-string v3, ""

    .line 44
    nop

    .line 45
    const/4 v4, 0x0

    if-eqz p1, :cond_2

    .line 46
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v5

    .line 47
    if-eqz v5, :cond_1

    .line 48
    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v3

    .line 50
    :cond_1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result p1

    goto :goto_0

    .line 45
    :cond_2
    move p1, v4

    .line 54
    :goto_0
    sget-wide v5, Lcom/calltimer/app/YkAutoFix;->sBackAt:J

    const-wide/16 v7, 0x0

    cmp-long v9, v5, v7

    if-eqz v9, :cond_3

    cmp-long v5, v1, v5

    if-ltz v5, :cond_3

    .line 55
    sput-wide v7, Lcom/calltimer/app/YkAutoFix;->sBackAt:J

    .line 56
    const/4 v5, 0x1

    invoke-virtual {p0, v5}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    .line 60
    :cond_3
    const-string v5, "com.yunke.enterprisep.miui"

    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-wide/16 v6, 0x5dc

    const/4 v8, 0x3

    if-eqz v5, :cond_4

    if-eqz p1, :cond_4

    .line 61
    sget-wide v9, Lcom/calltimer/app/YkAutoFix;->sLastAgree:J

    sub-long v9, v1, v9

    cmp-long p1, v9, v6

    if-lez p1, :cond_4

    .line 62
    sput-wide v1, Lcom/calltimer/app/YkAutoFix;->sLastAgree:J

    .line 63
    invoke-virtual {p0}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object p1

    .line 64
    if-eqz p1, :cond_4

    const-string v5, "\u540c\u610f"

    invoke-static {p1, v5, v8}, Lcom/calltimer/app/YkAutoFix;->clickExactText(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_4

    .line 65
    const-string p1, "agree clicked"

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 71
    :cond_4
    const-string p1, "com.android.settings"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    sget-boolean p1, Lcom/calltimer/app/YkAutoFix;->sRepairing:Z

    if-eqz p1, :cond_5

    .line 72
    sget-wide v9, Lcom/calltimer/app/YkAutoFix;->sLastRepairClick:J

    sub-long v9, v1, v9

    const-wide/16 v11, 0x258

    cmp-long p1, v9, v11

    if-lez p1, :cond_5

    .line 73
    sput-wide v1, Lcom/calltimer/app/YkAutoFix;->sLastRepairClick:J

    .line 74
    invoke-virtual {p0}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object p1

    .line 75
    if-eqz p1, :cond_5

    const-string v3, "\u672a\u542f\u7528"

    invoke-static {p1, v3, v8}, Lcom/calltimer/app/YkAutoFix;->clickExactText(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_5

    .line 76
    const-string p1, "ime toggle clicked"

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 77
    sput-boolean v4, Lcom/calltimer/app/YkAutoFix;->sRepairing:Z

    .line 78
    add-long/2addr v6, v1

    sput-wide v6, Lcom/calltimer/app/YkAutoFix;->sBackAt:J

    .line 84
    :cond_5
    sget-wide v3, Lcom/calltimer/app/YkAutoFix;->sLastCheck:J

    sub-long v3, v1, v3

    const-wide/16 v5, 0x3a98

    cmp-long p1, v3, v5

    if-lez p1, :cond_6

    sget p1, Lcom/calltimer/app/YkAutoFix;->sRepairTries:I

    if-ge p1, v8, :cond_6

    .line 85
    sput-wide v1, Lcom/calltimer/app/YkAutoFix;->sLastCheck:J

    .line 86
    invoke-static {p0}, Lcom/calltimer/app/YkAutoFix;->ensureIme(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 90
    :cond_6
    goto :goto_1

    .line 88
    :catchall_0
    move-exception p0

    .line 89
    const-string p1, "handle fail"

    invoke-static {v0, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 91
    :goto_1
    return-void
.end method
