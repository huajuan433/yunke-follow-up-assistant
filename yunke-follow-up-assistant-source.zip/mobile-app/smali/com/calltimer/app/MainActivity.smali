.class public Lcom/calltimer/app/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# static fields
.field private static final REQ_CALL_LOG:I = 0xc8

.field private static final REQ_NOTI:I = 0x65

.field private static final REQ_PHONE:I = 0x64


# instance fields
.field private etSeconds:Landroid/widget/EditText;

.field private final main:Landroid/os/Handler;

.field private final saveSeconds:Ljava/lang/Runnable;

.field private swCountdown:Landroid/widget/Switch;

.field private swEnable:Landroid/widget/Switch;

.field private swOverlay:Landroid/widget/Switch;

.field private swOverlayOnTop:Landroid/widget/Switch;

.field private syncing:Z

.field private tvA11y:Landroid/widget/TextView;

.field private tvAutoStart:Landroid/widget/TextView;

.field private tvBattery:Landroid/widget/TextView;

.field private tvCallLog:Landroid/widget/TextView;

.field private tvNoti:Landroid/widget/TextView;

.field private tvPhone:Landroid/widget/TextView;

.field private tvStatus:Landroid/widget/TextView;


# direct methods
.method public static synthetic $r8$lambda$gp9529Xhfe-0Iti2qyvOY4x59oA(Lcom/calltimer/app/MainActivity;Landroid/widget/CompoundButton;Z)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/calltimer/app/MainActivity;->lambda$onCreate$1(Landroid/widget/CompoundButton;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$lt_xzQZE8RQU1fMSji54QjeUzMM(Lcom/calltimer/app/MainActivity;Landroid/widget/CompoundButton;Z)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/calltimer/app/MainActivity;->lambda$onCreate$0(Landroid/widget/CompoundButton;Z)V

    return-void
.end method

.method public static synthetic $r8$lambda$nsvK9VRJNtgIe1XYql3TOb-TUCY(Lcom/calltimer/app/MainActivity;Ljava/lang/String;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lcom/calltimer/app/MainActivity;->lambda$showCrashDialog$2(Ljava/lang/String;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetmain(Lcom/calltimer/app/MainActivity;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/calltimer/app/MainActivity;->main:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetsaveSeconds(Lcom/calltimer/app/MainActivity;)Ljava/lang/Runnable;
    .locals 0

    iget-object p0, p0, Lcom/calltimer/app/MainActivity;->saveSeconds:Ljava/lang/Runnable;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mreadSeconds(Lcom/calltimer/app/MainActivity;)Ljava/lang/Integer;
    .locals 0

    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->readSeconds()Ljava/lang/Integer;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mrefreshService(Lcom/calltimer/app/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->refreshService()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mrefreshStatus(Lcom/calltimer/app/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->refreshStatus()V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 25
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 36
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/calltimer/app/MainActivity;->main:Landroid/os/Handler;

    const/4 v0, 0x0

    .line 37
    iput-boolean v0, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    .line 38
    new-instance v0, Lcom/calltimer/app/MainActivity$1;

    invoke-direct {v0, p0}, Lcom/calltimer/app/MainActivity$1;-><init>(Lcom/calltimer/app/MainActivity;)V

    iput-object v0, p0, Lcom/calltimer/app/MainActivity;->saveSeconds:Ljava/lang/Runnable;

    return-void
.end method

.method private disableService()V
    .locals 3

    const/4 v0, 0x0

    .line 173
    invoke-static {p0, v0}, Lcom/calltimer/app/Prefs;->setEnabled(Landroid/content/Context;Z)V

    .line 174
    new-instance v1, Landroid/content/Intent;

    const-class v2, Lcom/calltimer/app/CallTimerService;

    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v1}, Lcom/calltimer/app/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 175
    sget v1, Lcom/calltimer/app/R$string;->disabled_toast:I

    invoke-static {p0, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 176
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->refreshStatus()V

    return-void
.end method

.method private enableService()V
    .locals 4

    .line 144
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->readSeconds()Ljava/lang/Integer;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    .line 145
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v3, 0x1

    if-ge v2, v3, :cond_0

    goto :goto_2

    .line 150
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {p0, v0}, Lcom/calltimer/app/Prefs;->setSeconds(Landroid/content/Context;I)V

    .line 151
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->hasPhonePerms()Z

    move-result v0

    if-nez v0, :cond_1

    .line 152
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->rollbackSwitch()V

    .line 153
    sget v0, Lcom/calltimer/app/R$string;->need_phone_perm:I

    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const/4 v0, 0x0

    .line 154
    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->reqPhone(Landroid/view/View;)V

    return-void

    .line 157
    :cond_1
    invoke-static {p0, v3}, Lcom/calltimer/app/Prefs;->setEnabled(Landroid/content/Context;Z)V

    .line 158
    new-instance v0, Landroid/content/Intent;

    const-class v2, Lcom/calltimer/app/CallTimerService;

    invoke-direct {v0, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 160
    :try_start_0
    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 162
    :catchall_0
    const-string v0, "\u670d\u52a1\u542f\u52a8\u53d7\u9650\uff0c\u8bf7\u68c0\u67e5\u7535\u6c60/\u81ea\u542f\u52a8\u8bbe\u7f6e"

    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 164
    :goto_0
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->isA11yEnabled()Z

    move-result v0

    if-nez v0, :cond_2

    .line 165
    sget v0, Lcom/calltimer/app/R$string;->need_a11y_perm:I

    invoke-static {p0, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_1

    .line 167
    :cond_2
    sget v0, Lcom/calltimer/app/R$string;->enabled_toast:I

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 169
    :goto_1
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->refreshStates()V

    return-void

    .line 146
    :cond_3
    :goto_2
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->rollbackSwitch()V

    .line 147
    const-string v0, "\u8bf7\u5148\u586b\u5199\u6b63\u786e\u7684\u79d2\u6570"

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private hasCallLogPermission()Z
    .locals 1

    .line 288
    const-string v0, "android.permission.READ_CALL_LOG"

    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private hasPhonePerms()Z
    .locals 1

    .line 196
    const-string v0, "android.permission.READ_PHONE_STATE"

    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "android.permission.ANSWER_PHONE_CALLS"

    .line 197
    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private isA11yEnabled()Z
    .locals 5

    const/4 v0, 0x0

    .line 310
    :try_start_0
    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "accessibility_enabled"

    invoke-static {v1, v2, v0}, Landroid/provider/Settings$Secure;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    .line 312
    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "enabled_accessibility_services"

    invoke-static {v2, v3}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 314
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "/"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-class v4, Lcom/calltimer/app/HangupAccessibilityService;

    .line 315
    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    if-ne v1, v4, :cond_0

    if-eqz v2, :cond_0

    .line 316
    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_0

    move v0, v4

    :catchall_0
    :cond_0
    return v0
.end method

.method private isBatteryWhitelisted()Z
    .locals 2

    .line 323
    const-string v0, "power"

    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    if-eqz v0, :cond_0

    .line 324
    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/PowerManager;->isIgnoringBatteryOptimizations(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private isNotiGranted()Z
    .locals 3

    .line 328
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    const/4 v2, 0x1

    if-ge v0, v1, :cond_0

    return v2

    .line 329
    :cond_0
    const-string v0, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    :goto_0
    return v2
.end method

.method private synthetic lambda$onCreate$0(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 79
    iget-boolean p1, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    if-eqz p1, :cond_0

    return-void

    .line 80
    :cond_0
    invoke-static {p0, p2}, Lcom/calltimer/app/Prefs;->setShowCountdown(Landroid/content/Context;Z)V

    .line 81
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->refreshService()V

    return-void
.end method

.method private synthetic lambda$onCreate$1(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 85
    iget-boolean p1, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    if-eqz p1, :cond_0

    return-void

    :cond_0
    if-eqz p2, :cond_1

    .line 87
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->enableService()V

    goto :goto_0

    .line 89
    :cond_1
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->disableService()V

    :goto_0
    return-void
.end method

.method private synthetic lambda$showCrashDialog$2(Ljava/lang/String;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 112
    const-string p2, "clipboard"

    .line 113
    invoke-virtual {p0, p2}, Lcom/calltimer/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/ClipboardManager;

    if-eqz p2, :cond_0

    .line 115
    const-string p3, "crash"

    invoke-static {p3, p1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 117
    :cond_0
    const-string p1, "\u5df2\u590d\u5236\uff0c\u53ef\u76f4\u63a5\u7c98\u8d34\u53d1\u7ed9\u5f00\u53d1\u8005"

    const/4 p2, 0x1

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private readSeconds()Ljava/lang/Integer;
    .locals 3

    const/4 v0, 0x0

    .line 125
    :try_start_0
    iget-object v1, p0, Lcom/calltimer/app/MainActivity;->etSeconds:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 126
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    return-object v0

    .line 127
    :cond_0
    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-object v0
.end method

.method private refreshService()V
    .locals 2

    .line 186
    sget-boolean v0, Lcom/calltimer/app/CallTimerService;->isRunning:Z

    if-eqz v0, :cond_0

    .line 188
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/calltimer/app/CallTimerService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    return-void
.end method

.method private refreshStates()V
    .locals 2

    const/4 v0, 0x1

    .line 339
    iput-boolean v0, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    .line 340
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->swEnable:Landroid/widget/Switch;

    sget-boolean v1, Lcom/calltimer/app/CallTimerService;->isRunning:Z

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    .line 341
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->swCountdown:Landroid/widget/Switch;

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isShowCountdown(Landroid/content/Context;)Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->swOverlay:Landroid/widget/Switch;

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isOverlayEnabled(Landroid/content/Context;)Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->swOverlayOnTop:Landroid/widget/Switch;

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isOverlayOnTop(Landroid/content/Context;)Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    const/4 v0, 0x0

    .line 342
    iput-boolean v0, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    .line 344
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvPhone:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->hasPhonePerms()Z

    move-result v1

    invoke-direct {p0, v0, v1}, Lcom/calltimer/app/MainActivity;->setState(Landroid/widget/TextView;Z)V

    .line 345
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvNoti:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->isNotiGranted()Z

    move-result v1

    invoke-direct {p0, v0, v1}, Lcom/calltimer/app/MainActivity;->setState(Landroid/widget/TextView;Z)V

    .line 346
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvBattery:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->isBatteryWhitelisted()Z

    move-result v1

    invoke-direct {p0, v0, v1}, Lcom/calltimer/app/MainActivity;->setState(Landroid/widget/TextView;Z)V

    .line 347
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvA11y:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->isA11yEnabled()Z

    move-result v1

    invoke-direct {p0, v0, v1}, Lcom/calltimer/app/MainActivity;->setState(Landroid/widget/TextView;Z)V

    .line 348
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvCallLog:Landroid/widget/TextView;

    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->hasCallLogPermission()Z

    move-result v1

    invoke-direct {p0, v0, v1}, Lcom/calltimer/app/MainActivity;->setState(Landroid/widget/TextView;Z)V

    .line 349
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvAutoStart:Landroid/widget/TextView;

    sget v1, Lcom/calltimer/app/R$string;->state_needed:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 350
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvAutoStart:Landroid/widget/TextView;

    sget v1, Lcom/calltimer/app/R$color;->text_sub:I

    invoke-virtual {p0, v1}, Lcom/calltimer/app/MainActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 351
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->refreshStatus()V

    return-void
.end method

.method private refreshStatus()V
    .locals 3

    .line 355
    sget-boolean v0, Lcom/calltimer/app/CallTimerService;->isRunning:Z

    if-eqz v0, :cond_0

    .line 356
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvStatus:Landroid/widget/TextView;

    sget v1, Lcom/calltimer/app/R$string;->status_running:I

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->getSeconds(Landroid/content/Context;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcom/calltimer/app/MainActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 357
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvStatus:Landroid/widget/TextView;

    sget v1, Lcom/calltimer/app/R$color;->state_green:I

    invoke-virtual {p0, v1}, Lcom/calltimer/app/MainActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_0

    .line 359
    :cond_0
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvStatus:Landroid/widget/TextView;

    sget v1, Lcom/calltimer/app/R$string;->status_stopped:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 360
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->tvStatus:Landroid/widget/TextView;

    sget v1, Lcom/calltimer/app/R$color;->text_sub:I

    invoke-virtual {p0, v1}, Lcom/calltimer/app/MainActivity;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    :goto_0
    return-void
.end method

.method private rollbackSwitch()V
    .locals 2

    const/4 v0, 0x1

    .line 180
    iput-boolean v0, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    .line 181
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->swEnable:Landroid/widget/Switch;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    .line 182
    iput-boolean v1, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    return-void
.end method

.method private setState(Landroid/widget/TextView;Z)V
    .locals 1

    if-eqz p2, :cond_0

    .line 334
    sget v0, Lcom/calltimer/app/R$string;->state_on:I

    goto :goto_0

    :cond_0
    sget v0, Lcom/calltimer/app/R$string;->state_off:I

    :goto_0
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(I)V

    if-eqz p2, :cond_1

    .line 335
    sget p2, Lcom/calltimer/app/R$color;->state_green:I

    goto :goto_1

    :cond_1
    sget p2, Lcom/calltimer/app/R$color;->state_red:I

    :goto_1
    invoke-virtual {p0, p2}, Lcom/calltimer/app/MainActivity;->getColor(I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method

.method private showCrashDialog(Ljava/lang/String;)V
    .locals 3

    .line 101
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 102
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v1, 0x41300000    # 11.0f

    .line 103
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v1, 0x20

    const/16 v2, 0x18

    .line 104
    invoke-virtual {v0, v1, v2, v1, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 105
    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 106
    new-instance v1, Landroid/widget/ScrollView;

    invoke-direct {v1, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 107
    invoke-virtual {v1, v0}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 108
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v2, "\u4e0a\u6b21\u95ea\u9000\u8bb0\u5f55\uff08\u70b9\u590d\u5236\u53d1\u7ed9\u5f00\u53d1\u8005\uff09"

    .line 109
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 110
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1}, Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda2;-><init>(Lcom/calltimer/app/MainActivity;Ljava/lang/String;)V

    .line 111
    const-string p1, "\u590d\u5236"

    invoke-virtual {v0, p1, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const-string v0, "\u5173\u95ed"

    const/4 v1, 0x0

    .line 119
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    .line 120
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 52
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 53
    sget p1, Lcom/calltimer/app/R$layout;->activity_main:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->setContentView(I)V

    invoke-static {p0}, Lcom/calltimer/app/App;->readAndClearCrash(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-direct {p0, v0}, Lcom/calltimer/app/MainActivity;->showCrashDialog(Ljava/lang/String;)V

    .line 55
    :cond_0
    sget p1, Lcom/calltimer/app/R$id;->et_seconds:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/EditText;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->etSeconds:Landroid/widget/EditText;

    .line 56
    sget p1, Lcom/calltimer/app/R$id;->sw_enable:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->swEnable:Landroid/widget/Switch;

    .line 57
    sget p1, Lcom/calltimer/app/R$id;->sw_countdown:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->swCountdown:Landroid/widget/Switch;

    sget p1, Lcom/calltimer/app/R$id;->sw_overlay:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->swOverlay:Landroid/widget/Switch;

    sget p1, Lcom/calltimer/app/R$id;->sw_overlay_ontop:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Switch;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->swOverlayOnTop:Landroid/widget/Switch;

    .line 58
    sget p1, Lcom/calltimer/app/R$id;->tv_status:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->tvStatus:Landroid/widget/TextView;

    .line 59
    sget p1, Lcom/calltimer/app/R$id;->tv_phone_state:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->tvPhone:Landroid/widget/TextView;

    .line 60
    sget p1, Lcom/calltimer/app/R$id;->tv_notification_state:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->tvNoti:Landroid/widget/TextView;

    .line 61
    sget p1, Lcom/calltimer/app/R$id;->tv_battery_state:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->tvBattery:Landroid/widget/TextView;

    .line 62
    sget p1, Lcom/calltimer/app/R$id;->tv_autostart_state:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->tvAutoStart:Landroid/widget/TextView;

    .line 63
    sget p1, Lcom/calltimer/app/R$id;->tv_a11y_state:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->tvA11y:Landroid/widget/TextView;

    .line 64
    sget p1, Lcom/calltimer/app/R$id;->tv_calllog_state:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/MainActivity;->tvCallLog:Landroid/widget/TextView;

    .line 66
    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->etSeconds:Landroid/widget/EditText;

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->getSeconds(Landroid/content/Context;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 67
    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->etSeconds:Landroid/widget/EditText;

    new-instance v0, Lcom/calltimer/app/MainActivity$2;

    invoke-direct {v0, p0}, Lcom/calltimer/app/MainActivity$2;-><init>(Lcom/calltimer/app/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 77
    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->swCountdown:Landroid/widget/Switch;

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isShowCountdown(Landroid/content/Context;)Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    .line 78
    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->swCountdown:Landroid/widget/Switch;

    new-instance v0, Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda0;-><init>(Lcom/calltimer/app/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 84
    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->swEnable:Landroid/widget/Switch;

    new-instance v0, Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda1;-><init>(Lcom/calltimer/app/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->swOverlay:Landroid/widget/Switch;

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isOverlayEnabled(Landroid/content/Context;)Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->swOverlay:Landroid/widget/Switch;

    new-instance v0, Lcom/calltimer/app/MainActivity$3;

    invoke-direct {v0, p0}, Lcom/calltimer/app/MainActivity$3;-><init>(Lcom/calltimer/app/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->swOverlayOnTop:Landroid/widget/Switch;

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isOverlayOnTop(Landroid/content/Context;)Z

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->swOverlayOnTop:Landroid/widget/Switch;

    new-instance v0, Lcom/calltimer/app/MainActivity$4;

    invoke-direct {v0, p0}, Lcom/calltimer/app/MainActivity$4;-><init>(Lcom/calltimer/app/MainActivity;)V

    invoke-virtual {p1, v0}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 94
    invoke-static {p0}, Lcom/calltimer/app/App;->readAndClearCrash(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 95
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1

    .line 96
    invoke-direct {p0, p1}, Lcom/calltimer/app/MainActivity;->showCrashDialog(Ljava/lang/String;)V

    :cond_1
    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isEnabled(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-boolean v0, Lcom/calltimer/app/CallTimerService;->isRunning:Z

    if-nez v0, :cond_2

    new-instance v0, Landroid/content/Intent;

    const-class p1, Lcom/calltimer/app/CallTimerService;

    invoke-direct {v0, p0, p1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    :try_start_0
    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_2
    return-void
.end method

.method public onOverlayOnTopToggle(Landroid/widget/CompoundButton;Z)V
    .locals 1

    iget-boolean v0, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-static {p0, p2}, Lcom/calltimer/app/Prefs;->setOverlayOnTop(Landroid/content/Context;Z)V

    invoke-static {}, Lcom/calltimer/app/YkOverlay;->hide()V

    invoke-static {p0}, Lcom/calltimer/app/YkOverlay;->show(Landroid/content/Context;)V

    return-void
.end method

.method public onOverlayToggle(Landroid/widget/CompoundButton;Z)V
    .locals 3

    iget-boolean v0, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    if-eqz p2, :cond_2

    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "package:"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p0, v1}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V

    const-string v0, "\u8bf7\u5148\u5141\u8bb8\u300c\u663e\u793a\u5728\u5176\u4ed6\u5e94\u7528\u4e0a\u5c42\u300d"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->swOverlay:Landroid/widget/Switch;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/calltimer/app/MainActivity;->syncing:Z

    return-void

    :cond_1
    invoke-static {p0, p2}, Lcom/calltimer/app/Prefs;->setOverlayEnabled(Landroid/content/Context;Z)V

    invoke-static {p0}, Lcom/calltimer/app/YkOverlay;->show(Landroid/content/Context;)V

    return-void

    :cond_2
    invoke-static {p0, p2}, Lcom/calltimer/app/Prefs;->setOverlayEnabled(Landroid/content/Context;Z)V

    invoke-static {}, Lcom/calltimer/app/YkOverlay;->hide()V

    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 0

    .line 378
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 379
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->refreshStates()V

    const/16 p2, 0x64

    const/4 p3, 0x0

    if-ne p1, p2, :cond_1

    .line 381
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->hasPhonePerms()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 382
    const-string p1, "\u7535\u8bdd\u6743\u9650\u5df2\u6388\u4e88"

    invoke-static {p0, p1, p3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 384
    :cond_0
    sget p1, Lcom/calltimer/app/R$string;->need_phone_perm:I

    const/4 p2, 0x1

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_0

    :cond_1
    const/16 p2, 0xc8

    if-ne p1, p2, :cond_2

    .line 387
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->hasCallLogPermission()Z

    move-result p1

    if-eqz p1, :cond_2

    .line 388
    const-string p1, "\u901a\u8bdd\u8bb0\u5f55\u6743\u9650\u5df2\u6388\u4e88"

    invoke-static {p0, p1, p3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_2
    :goto_0
    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 366
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 368
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->readSeconds()Ljava/lang/Integer;

    move-result-object v0

    .line 369
    invoke-static {p0}, Lcom/calltimer/app/Prefs;->getSeconds(Landroid/content/Context;)I

    move-result v1

    if-eqz v0, :cond_0

    .line 370
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-eq v0, v1, :cond_1

    .line 371
    :cond_0
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->etSeconds:Landroid/widget/EditText;

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 373
    :cond_1
    invoke-direct {p0}, Lcom/calltimer/app/MainActivity;->refreshStates()V

    invoke-static {p0}, Lcom/calltimer/app/YkOverlay;->show(Landroid/content/Context;)V

    return-void
.end method

.method public openCheck(Landroid/view/View;)V
    .locals 1

    .line 303
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/calltimer/app/CheckConnectionActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public openRecommend(Landroid/view/View;)V
    .locals 1

    .line 298
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lcom/calltimer/app/RecommendActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public quickPick(Landroid/view/View;)V
    .locals 1

    .line 135
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    .line 137
    :cond_0
    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->etSeconds:Landroid/widget/EditText;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 138
    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->main:Landroid/os/Handler;

    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->saveSeconds:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 139
    iget-object p1, p0, Lcom/calltimer/app/MainActivity;->main:Landroid/os/Handler;

    iget-object v0, p0, Lcom/calltimer/app/MainActivity;->saveSeconds:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 140
    sget p1, Lcom/calltimer/app/R$string;->seconds_saved:I

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public reqA11y(Landroid/view/View;)V
    .locals 1

    .line 281
    :try_start_0
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.settings.ACCESSIBILITY_SETTINGS"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 283
    :catchall_0
    const-string p1, "\u8bf7\u624b\u52a8\u5230\u8bbe\u7f6e\u4e2d\u5f00\u542f\u65e0\u969c\u788d"

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method public reqAutoStart(Landroid/view/View;)V
    .locals 8

    .line 255
    new-instance p1, Landroid/content/Intent;

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    const/4 v0, 0x2

    .line 256
    new-array v1, v0, [[Ljava/lang/String;

    new-array v2, v0, [Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "com.miui.securitycenter"

    aput-object v4, v2, v3

    const-string v5, "com.miui.permcenter.autostart.AutoStartManagementActivity"

    const/4 v6, 0x1

    aput-object v5, v2, v6

    aput-object v2, v1, v3

    new-array v2, v0, [Ljava/lang/String;

    aput-object v4, v2, v3

    const-string v4, "com.miui.permcenter.permissions.PermissionsEditorActivity"

    aput-object v4, v2, v6

    aput-object v2, v1, v6

    move v2, v3

    :goto_0
    if-ge v2, v0, :cond_0

    .line 262
    aget-object v4, v1, v2

    .line 264
    :try_start_0
    new-instance v5, Landroid/content/ComponentName;

    aget-object v7, v4, v3

    aget-object v4, v4, v6

    invoke-direct {v5, v7, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1, v5}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 265
    const-string v4, "extra_pkgname"

    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v4, 0x10000000

    .line 266
    invoke-virtual {p1, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 267
    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 272
    :cond_0
    new-instance p1, Landroid/app/AlertDialog$Builder;

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v0, Lcom/calltimer/app/R$string;->autostart_dialog_title:I

    .line 273
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(I)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    sget v0, Lcom/calltimer/app/R$string;->autostart_dialog_body:I

    .line 274
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    sget v0, Lcom/calltimer/app/R$string;->dialog_ok:I

    const/4 v1, 0x0

    .line 275
    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    .line 276
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method public reqBattery(Landroid/view/View;)V
    .locals 3

    const-string p1, "package:"

    .line 238
    const-string v0, "power"

    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    if-eqz v0, :cond_0

    .line 239
    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/PowerManager;->isIgnoringBatteryOptimizations(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 240
    const-string p1, "\u7535\u6c60\u4f18\u5316\u767d\u540d\u5355\u5df2\u5f00\u542f"

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    .line 244
    :cond_0
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 245
    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-direct {v0, v1, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 246
    invoke-virtual {p0, v0}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 249
    :catchall_0
    :try_start_1
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    :goto_0
    return-void
.end method

.method public reqCallLog(Landroid/view/View;)V
    .locals 2

    const/4 p1, 0x1

    .line 293
    new-array p1, p1, [Ljava/lang/String;

    const/4 v0, 0x0

    const-string v1, "android.permission.READ_CALL_LOG"

    aput-object v1, p1, v0

    const/16 v0, 0xc8

    invoke-virtual {p0, p1, v0}, Lcom/calltimer/app/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    return-void
.end method

.method public reqNotification(Landroid/view/View;)V
    .locals 2

    .line 218
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x21

    if-lt p1, v0, :cond_0

    .line 219
    const-string p1, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    .line 221
    new-array v0, v0, [Ljava/lang/String;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    const/16 p1, 0x65

    invoke-virtual {p0, v0, p1}, Lcom/calltimer/app/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    return-void

    .line 225
    :cond_0
    :try_start_0
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.settings.APP_NOTIFICATION_SETTINGS"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 226
    const-string v0, "android.provider.extra.APP_PACKAGE"

    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 227
    const-string v0, "app_package"

    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 228
    const-string v0, "app_uid"

    invoke-virtual {p0}, Lcom/calltimer/app/MainActivity;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->uid:I

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 229
    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 232
    :catchall_0
    :try_start_1
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.settings.SETTINGS"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Lcom/calltimer/app/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    :goto_0
    return-void
.end method

.method public reqPhone(Landroid/view/View;)V
    .locals 6

    .line 202
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x21

    const-string v1, "android.permission.ANSWER_PHONE_CALLS"

    const/4 v2, 0x1

    const-string v3, "android.permission.READ_PHONE_STATE"

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-lt p1, v0, :cond_0

    const/4 p1, 0x3

    .line 203
    new-array p1, p1, [Ljava/lang/String;

    aput-object v3, p1, v4

    aput-object v1, p1, v2

    const-string v0, "android.permission.POST_NOTIFICATIONS"

    aput-object v0, p1, v5

    goto :goto_0

    .line 209
    :cond_0
    new-array p1, v5, [Ljava/lang/String;

    aput-object v3, p1, v4

    aput-object v1, p1, v2

    :goto_0
    const/16 v0, 0x64

    .line 214
    invoke-virtual {p0, p1, v0}, Lcom/calltimer/app/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    return-void
.end method
