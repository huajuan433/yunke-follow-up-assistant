.class public final Lcom/calltimer/app/YkOverlay$4;
.super Ljava/lang/Object;
.source "YkOverlay.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Prefs;->isEnabled(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-static {v0, v1}, Lcom/calltimer/app/Prefs;->setEnabled(Landroid/content/Context;Z)V

    invoke-static {}, Lcom/calltimer/app/YkOverlay;->refresh()V

    return-void
.end method
