.class public Lcom/calltimer/app/CheckConnectionActivity;
.super Landroid/app/Activity;
.source "CheckConnectionActivity.java"


# instance fields
.field private final mMain:Landroid/os/Handler;

.field private final mRefresh:Ljava/lang/Runnable;

.field private tvLog:Landroid/widget/TextView;

.field private tvScan:Landroid/widget/TextView;

.field private tvStatus:Landroid/widget/TextView;


# direct methods
.method static bridge synthetic -$$Nest$fgetmMain(Lcom/calltimer/app/CheckConnectionActivity;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/calltimer/app/CheckConnectionActivity;->mMain:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mrender(Lcom/calltimer/app/CheckConnectionActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/calltimer/app/CheckConnectionActivity;->render()V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 20
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 23
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/calltimer/app/CheckConnectionActivity;->mMain:Landroid/os/Handler;

    .line 25
    new-instance v0, Lcom/calltimer/app/CheckConnectionActivity$1;

    invoke-direct {v0, p0}, Lcom/calltimer/app/CheckConnectionActivity$1;-><init>(Lcom/calltimer/app/CheckConnectionActivity;)V

    iput-object v0, p0, Lcom/calltimer/app/CheckConnectionActivity;->mRefresh:Ljava/lang/Runnable;

    return-void
.end method

.method private render()V
    .locals 4

    .line 56
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->isReady()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 58
    const-string v1, "\u65e0\u969c\u788d\u670d\u52a1\u72b6\u6001\uff1a\u5df2\u8fde\u63a5 \u2713\n"

    goto :goto_0

    .line 59
    :cond_0
    const-string v1, "\u65e0\u969c\u788d\u670d\u52a1\u72b6\u6001\uff1a\u672a\u8fde\u63a5 \u2717\uff08\u8bf7\u70b9\u4e0b\u65b9\u6309\u94ae\u5230\u7cfb\u7edf\u8bbe\u7f6e\u91cc\u5f00\u542f\u201c\u5b9a\u65f6\u6302\u65ad-\u63a5\u901a\u8bc6\u522b\u4e0e\u6302\u65ad\u201d\uff0cMIUI \u53ef\u80fd\u4f1a\u81ea\u52a8\u5173\u95ed\u5b83\uff09\n"

    .line 60
    :goto_0
    iget-object v2, p0, Lcom/calltimer/app/CheckConnectionActivity;->tvStatus:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Lcom/calltimer/app/CheckConnectionActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Lcom/calltimer/app/CallTimerService;->getDebugSnapshot(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 61
    iget-object v1, p0, Lcom/calltimer/app/CheckConnectionActivity;->tvStatus:Landroid/widget/TextView;

    if-eqz v0, :cond_1

    const v0, -0xd182ce

    goto :goto_1

    :cond_1
    const v0, -0x39d7d8

    :goto_1
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 63
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->scanNow()Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    move-result-object v0

    .line 64
    iget-object v1, p0, Lcom/calltimer/app/CheckConnectionActivity;->tvScan:Landroid/widget/TextView;

    if-nez v0, :cond_2

    const-string v0, "\u65e0\u969c\u788d\u672a\u8fd0\u884c\uff0c\u65e0\u6cd5\u626b\u63cf"

    goto :goto_2

    :cond_2
    invoke-virtual {v0}, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_2
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 66
    iget-object v0, p0, Lcom/calltimer/app/CheckConnectionActivity;->tvLog:Landroid/widget/TextView;

    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->getLogText()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private safeScan()Ljava/lang/Object;
    .locals 1

    .line 88
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->scanNow()Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    move-result-object v0

    if-nez v0, :cond_0

    .line 89
    const-string v0, "\u670d\u52a1\u672a\u8fd0\u884c"

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0
.end method


# virtual methods
.method public onCopy(Landroid/view/View;)V
    .locals 2

    .line 70
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "=== \u5b9a\u65f6\u6302\u65ad \u63a5\u901a\u8bc6\u522b\u8bca\u65ad ===\n\u673a\u578b: "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "\n\u7cfb\u7edf: "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " (SDK "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, ")\n\n\u8fd0\u884c\u5feb\u7167:\n"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 75
    invoke-virtual {p0}, Lcom/calltimer/app/CheckConnectionActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->getDebugSnapshot(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "\n\u5b9e\u65f6\u626b\u63cf:\n"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 77
    invoke-direct {p0}, Lcom/calltimer/app/CheckConnectionActivity;->safeScan()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "\n\n\u4e8b\u4ef6\u65e5\u5fd7:\n"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 79
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->getLogText()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 80
    const-string v0, "clipboard"

    invoke-virtual {p0, v0}, Lcom/calltimer/app/CheckConnectionActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    if-eqz v0, :cond_0

    .line 82
    const-string v1, "calltimer-diag"

    invoke-static {v1, p1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 83
    const-string p1, "\u8bca\u65ad\u65e5\u5fd7\u5df2\u590d\u5236\uff0c\u53ef\u7c98\u8d34\u53d1\u7ed9\u5f00\u53d1\u8005"

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    .line 35
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 36
    sget p1, Lcom/calltimer/app/R$layout;->activity_check:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/CheckConnectionActivity;->setContentView(I)V

    .line 37
    const-string p1, "\u63a5\u901a\u8bc6\u522b\u81ea\u68c0"

    invoke-virtual {p0, p1}, Lcom/calltimer/app/CheckConnectionActivity;->setTitle(Ljava/lang/CharSequence;)V

    .line 38
    sget p1, Lcom/calltimer/app/R$id;->tv_status:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/CheckConnectionActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/CheckConnectionActivity;->tvStatus:Landroid/widget/TextView;

    .line 39
    sget p1, Lcom/calltimer/app/R$id;->tv_scan:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/CheckConnectionActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/CheckConnectionActivity;->tvScan:Landroid/widget/TextView;

    .line 40
    sget p1, Lcom/calltimer/app/R$id;->tv_log:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/CheckConnectionActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/CheckConnectionActivity;->tvLog:Landroid/widget/TextView;

    return-void
.end method

.method public onOpenA11y(Landroid/view/View;)V
    .locals 1

    .line 94
    :try_start_0
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.settings.ACCESSIBILITY_SETTINGS"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/high16 v0, 0x10000000

    .line 95
    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    .line 94
    invoke-virtual {p0, p1}, Lcom/calltimer/app/CheckConnectionActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 97
    :catchall_0
    const-string p1, "\u8bf7\u624b\u52a8\u5230 \u8bbe\u7f6e-\u66f4\u591a\u8bbe\u7f6e-\u65e0\u969c\u788d \u4e2d\u5f00\u542f"

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method protected onPause()V
    .locals 2

    .line 51
    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    .line 52
    iget-object v0, p0, Lcom/calltimer/app/CheckConnectionActivity;->mMain:Landroid/os/Handler;

    iget-object v1, p0, Lcom/calltimer/app/CheckConnectionActivity;->mRefresh:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 45
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 46
    iget-object v0, p0, Lcom/calltimer/app/CheckConnectionActivity;->mMain:Landroid/os/Handler;

    iget-object v1, p0, Lcom/calltimer/app/CheckConnectionActivity;->mRefresh:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
