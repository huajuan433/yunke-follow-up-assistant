.class Lcom/calltimer/app/CheckConnectionActivity$1;
.super Ljava/lang/Object;
.source "CheckConnectionActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/CheckConnectionActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/CheckConnectionActivity;


# direct methods
.method constructor <init>(Lcom/calltimer/app/CheckConnectionActivity;)V
    .locals 0

    .line 25
    iput-object p1, p0, Lcom/calltimer/app/CheckConnectionActivity$1;->this$0:Lcom/calltimer/app/CheckConnectionActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 28
    iget-object v0, p0, Lcom/calltimer/app/CheckConnectionActivity$1;->this$0:Lcom/calltimer/app/CheckConnectionActivity;

    invoke-static {v0}, Lcom/calltimer/app/CheckConnectionActivity;->-$$Nest$mrender(Lcom/calltimer/app/CheckConnectionActivity;)V

    .line 29
    iget-object v0, p0, Lcom/calltimer/app/CheckConnectionActivity$1;->this$0:Lcom/calltimer/app/CheckConnectionActivity;

    invoke-static {v0}, Lcom/calltimer/app/CheckConnectionActivity;->-$$Nest$fgetmMain(Lcom/calltimer/app/CheckConnectionActivity;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x5dc

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
