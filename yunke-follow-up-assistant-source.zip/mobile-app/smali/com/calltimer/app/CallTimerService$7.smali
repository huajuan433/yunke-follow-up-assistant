.class Lcom/calltimer/app/CallTimerService$7;
.super Ljava/lang/Object;
.source "CallTimerService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/calltimer/app/CallTimerService;->finalizeHangup()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/CallTimerService;


# direct methods
.method constructor <init>(Lcom/calltimer/app/CallTimerService;)V
    .locals 0

    .line 589
    iput-object p1, p0, Lcom/calltimer/app/CallTimerService$7;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 593
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$7;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$mreadCallState(Lcom/calltimer/app/CallTimerService;)I

    move-result v0

    if-eqz v0, :cond_0

    .line 594
    const-string v0, "HANGUP flow finished but call alive, manual alert"

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 595
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$7;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$mnotifyHangupFailed(Lcom/calltimer/app/CallTimerService;)V

    :cond_0
    return-void
.end method
