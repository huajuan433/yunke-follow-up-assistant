.class public Lcom/calltimer/app/HangupAccessibilityService;
.super Landroid/accessibilityservice/AccessibilityService;
.source "HangupAccessibilityService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;,
        Lcom/calltimer/app/HangupAccessibilityService$ScanResult;,
        Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;
    }
.end annotation


# static fields
.field private static final BUSY_TEXT_HINTS:[Ljava/lang/String;

.field private static final CALL_UI_TEXT_HINTS:[Ljava/lang/String;

.field private static final CONNECTED_TEXT_HINTS:[Ljava/lang/String;

.field private static final DIALING_TEXT_HINTS:[Ljava/lang/String;

.field private static final HANGUP_ID_HINTS:[Ljava/lang/String;

.field private static final HANGUP_TEXT_HINTS:[Ljava/lang/String;

.field private static final MAX_NODES:I = 0x190

.field private static final MAX_TRIES:I = 0x6

.field private static final PKG_HINTS:[Ljava/lang/String;

.field private static final RETRY_INTERVAL:J = 0x320L

.field private static final TAG:Ljava/lang/String; = "A11yHangup"

.field private static final TIMER_ID_HINTS:[Ljava/lang/String;

.field private static final TIMER_TEXT_EMBED:Ljava/util/regex/Pattern;

.field private static final TIMER_TEXT_EXACT:Ljava/util/regex/Pattern;

.field public static sBusyReason:Ljava/lang/String;

.field public static sCallNumber:Ljava/lang/String;

.field private static volatile sInstance:Lcom/calltimer/app/HangupAccessibilityService;

.field private static sRemarkFirst:J

.field private static sRemarkHit:Z

.field private static sRemarkLabel:Z

.field private static sRemarkSeen:Ljava/util/HashSet;

.field private static sToastBusy:J

.field private static final sWatch:Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;


# instance fields
.field private mCurrent:Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;

.field private mLastEventScan:J

.field private final mMain:Landroid/os/Handler;


# direct methods
.method public static synthetic $r8$lambda$WygMJnM_L-Gr7-q74_y09EBRFwc(Lcom/calltimer/app/HangupAccessibilityService;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/calltimer/app/HangupAccessibilityService;->lambda$onAccessibilityEvent$0(Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetmMain(Lcom/calltimer/app/HangupAccessibilityService;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lcom/calltimer/app/HangupAccessibilityService;->mMain:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mattemptHangup(Lcom/calltimer/app/HangupAccessibilityService;)Z
    .locals 0

    invoke-direct {p0}, Lcom/calltimer/app/HangupAccessibilityService;->attemptHangup()Z

    move-result p0

    return p0
.end method

.method static constructor <clinit>()V
    .locals 17

    .line 41
    new-instance v0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;

    invoke-direct {v0}, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;-><init>()V

    sput-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sWatch:Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;

    const/4 v0, 0x7

    .line 46
    new-array v1, v0, [Ljava/lang/String;

    const-string v2, "incallui"

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const-string v2, "callui"

    const/4 v4, 0x1

    aput-object v2, v1, v4

    const-string v2, "telecom"

    const/4 v5, 0x2

    aput-object v2, v1, v5

    const-string v2, "dialer"

    const/4 v6, 0x3

    aput-object v2, v1, v6

    const-string v2, "phone"

    const/4 v7, 0x4

    aput-object v2, v1, v7

    const-string v2, "call"

    const/4 v8, 0x5

    aput-object v2, v1, v8

    const-string v2, "contacts"

    const/4 v9, 0x6

    aput-object v2, v1, v9

    sput-object v1, Lcom/calltimer/app/HangupAccessibilityService;->PKG_HINTS:[Ljava/lang/String;

    const/16 v1, 0xa

    .line 49
    new-array v2, v1, [Ljava/lang/String;

    const-string v10, "end"

    aput-object v10, v2, v3

    const-string v10, "disconnect"

    aput-object v10, v2, v4

    const-string v11, "hangup"

    aput-object v11, v2, v5

    const-string v12, "hang_up"

    aput-object v12, v2, v6

    const-string v12, "endcall"

    aput-object v12, v2, v7

    const-string v13, "end_call"

    aput-object v13, v2, v8

    const-string v13, "incall_end"

    aput-object v13, v2, v9

    const-string v13, "endbutton"

    aput-object v13, v2, v0

    const-string v13, "stop_call"

    const/16 v14, 0x8

    aput-object v13, v2, v14

    const-string v13, "btn_end"

    const/16 v15, 0x9

    aput-object v13, v2, v15

    sput-object v2, Lcom/calltimer/app/HangupAccessibilityService;->HANGUP_ID_HINTS:[Ljava/lang/String;

    .line 53
    new-array v2, v0, [Ljava/lang/String;

    const-string v13, "\u6302\u65ad"

    aput-object v13, v2, v3

    const-string v16, "\u7ed3\u675f\u901a\u8bdd"

    aput-object v16, v2, v4

    const-string v16, "hang up"

    aput-object v16, v2, v5

    aput-object v11, v2, v6

    const-string v11, "end call"

    aput-object v11, v2, v7

    aput-object v12, v2, v8

    aput-object v10, v2, v9

    sput-object v2, Lcom/calltimer/app/HangupAccessibilityService;->HANGUP_TEXT_HINTS:[Ljava/lang/String;

    const/16 v2, 0xb

    .line 58
    new-array v10, v2, [Ljava/lang/String;

    const-string v11, "elapsed"

    aput-object v11, v10, v3

    const-string v11, "chronometer"

    aput-object v11, v10, v4

    const-string v11, "calltime"

    aput-object v11, v10, v5

    const-string v11, "call_time"

    aput-object v11, v10, v6

    const-string v11, "callduration"

    aput-object v11, v10, v7

    const-string v11, "call_duration"

    aput-object v11, v10, v8

    const-string v11, "durationtext"

    aput-object v11, v10, v9

    const-string v11, "duration_text"

    aput-object v11, v10, v0

    const-string v11, "calldurationtext"

    aput-object v11, v10, v14

    const-string v11, "timer"

    aput-object v11, v10, v15

    const-string v11, "duration"

    aput-object v11, v10, v1

    sput-object v10, Lcom/calltimer/app/HangupAccessibilityService;->TIMER_ID_HINTS:[Ljava/lang/String;

    .line 64
    new-array v10, v6, [Ljava/lang/String;

    const-string v11, "\u5df2\u63a5\u901a"

    aput-object v11, v10, v3

    const-string v11, "\u901a\u8bdd\u8ba1\u65f6"

    aput-object v11, v10, v4

    const-string v11, "\u901a\u8bdd\u5df2\u63a5\u901a"

    aput-object v11, v10, v5

    sput-object v10, Lcom/calltimer/app/HangupAccessibilityService;->CONNECTED_TEXT_HINTS:[Ljava/lang/String;

    const/16 v14, 0xb

    .line 67
    new-array v10, v14, [Ljava/lang/String;

    const-string v11, "\u6682\u65f6\u65e0\u6cd5\u63a5\u901a"

    aput-object v11, v10, v3

    const-string v11, "\u5df2\u5173\u673a"

    aput-object v11, v10, v4

    const-string v11, "\u6b63\u5728\u901a\u8bdd\u4e2d\uff0c\u8bf7\u7a0d\u540e"

    aput-object v11, v10, v5

    const-string v11, "\u7528\u6237\u6b63\u5fd9"

    aput-object v11, v10, v6

    const-string v11, "\u5bf9\u65b9\u5fd9"

    aput-object v11, v10, v7

    const-string v11, "\u8bed\u97f3\u4fe1\u7bb1"

    aput-object v11, v10, v8

    const-string v11, "\u65e0\u6cd5\u63a5\u901a"

    aput-object v11, v10, v9

    const-string v11, "\u505c\u673a"

    aput-object v11, v10, v0

    const/16 v14, 0x8

    const-string v11, "\u7a7a\u53f7"

    aput-object v11, v10, v14

    const/16 v14, 0x9

    const-string v11, "\u5360\u7ebf"

    aput-object v11, v10, v14

    const/16 v14, 0xa

    const-string v11, "\u901a\u8bdd\u4e2d\uff0c\u8bf7\u7a0d\u540e"

    aput-object v11, v10, v14

    sput-object v10, Lcom/calltimer/app/HangupAccessibilityService;->BUSY_TEXT_HINTS:[Ljava/lang/String;

    const/16 v14, 0x8

    const/16 v10, 0x15

    .line 71
    new-array v10, v10, [Ljava/lang/String;

    const-string v11, "\u6b63\u5728\u547c\u53eb"

    aput-object v11, v10, v3

    const-string v11, "\u6b63\u5728\u62e8\u53f7"

    aput-object v11, v10, v4

    const-string v11, "\u62e8\u53f7\u4e2d"

    aput-object v11, v10, v5

    const-string v11, "\u6b63\u5728\u7b49\u5f85"

    aput-object v11, v10, v6

    const-string v11, "\u7b49\u5f85\u5bf9\u65b9"

    aput-object v11, v10, v7

    const-string v11, "\u54cd\u94c3\u4e2d"

    aput-object v11, v10, v8

    const-string v11, "\u632f\u94c3\u4e2d"

    aput-object v11, v10, v9

    const-string v11, "\u6b63\u5728\u63a5\u901a"

    aput-object v11, v10, v0

    const-string v11, "\u6b63\u5728\u8fde\u63a5"

    aput-object v11, v10, v14

    const-string v11, "\u5bf9\u65b9\u6b63\u5728"

    aput-object v11, v10, v15

    const-string v11, "\u547c\u53eb\u4e2d"

    aput-object v11, v10, v1

    const-string v11, "\u6b63\u5728\u54cd\u94c3"

    aput-object v11, v10, v2

    const-string v11, "\u62e8\u6253\u4e2d"

    const/16 v12, 0xc

    aput-object v11, v10, v12

    const/16 v11, 0xd

    const-string v16, "\u6b63\u5728\u62e8\u51fa"

    aput-object v16, v10, v11

    const/16 v11, 0xe

    const-string v16, "\u547c\u53eb\u7b49\u5f85\u4e2d"

    aput-object v16, v10, v11

    const/16 v11, 0xf

    const-string v16, "\u7b49\u5f85\u63a5\u901a"

    aput-object v16, v10, v11

    const/16 v11, 0x10

    const-string v16, "dialing"

    aput-object v16, v10, v11

    const/16 v11, 0x11

    const-string v16, "alerting"

    aput-object v16, v10, v11

    const/16 v11, 0x12

    const-string v16, "ringing"

    aput-object v16, v10, v11

    const/16 v11, 0x13

    const-string v16, "calling"

    aput-object v16, v10, v11

    const/16 v11, 0x14

    const-string v16, "connecting"

    aput-object v16, v10, v11

    sput-object v10, Lcom/calltimer/app/HangupAccessibilityService;->DIALING_TEXT_HINTS:[Ljava/lang/String;

    .line 78
    new-array v10, v12, [Ljava/lang/String;

    aput-object v13, v10, v3

    const-string v3, "\u514d\u63d0"

    aput-object v3, v10, v4

    const-string v3, "\u9759\u97f3"

    aput-object v3, v10, v5

    const-string v3, "\u626c\u58f0\u5668"

    aput-object v3, v10, v6

    const-string v3, "\u62e8\u53f7\u76d8"

    aput-object v3, v10, v7

    const-string v3, "\u6dfb\u52a0\u901a\u8bdd"

    aput-object v3, v10, v8

    const-string v3, "\u901a\u8bdd\u5f55\u97f3"

    aput-object v3, v10, v9

    const-string v3, "\u4fdd\u6301"

    aput-object v3, v10, v0

    const-string v0, "\u89c6\u9891\u901a\u8bdd"

    aput-object v0, v10, v14

    const-string v0, "\u901a\u8baf\u5f55"

    aput-object v0, v10, v15

    const-string v0, "mute"

    aput-object v0, v10, v1

    const-string v0, "speaker"

    aput-object v0, v10, v2

    sput-object v10, Lcom/calltimer/app/HangupAccessibilityService;->CALL_UI_TEXT_HINTS:[Ljava/lang/String;

    .line 83
    const-string v0, "^\\d{1,2}:[0-5]\\d$"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/calltimer/app/HangupAccessibilityService;->TIMER_TEXT_EXACT:Ljava/util/regex/Pattern;

    .line 85
    const-string v0, "(?:\u8ba1\u65f6|\u65f6\u957f|\u901a\u8bdd\u65f6\u95f4|\u901a\u8bdd)[^0-9]{0,6}(\\d{1,2}:[0-5]\\d)"

    .line 86
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/calltimer/app/HangupAccessibilityService;->TIMER_TEXT_EMBED:Ljava/util/regex/Pattern;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 32
    invoke-direct {p0}, Landroid/accessibilityservice/AccessibilityService;-><init>()V

    .line 42
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService;->mMain:Landroid/os/Handler;

    const-wide/16 v0, 0x0

    .line 44
    iput-wide v0, p0, Lcom/calltimer/app/HangupAccessibilityService;->mLastEventScan:J

    return-void
.end method

.method private attemptHangup()Z
    .locals 7

    .line 483
    invoke-direct {p0}, Lcom/calltimer/app/HangupAccessibilityService;->wakeScreen()V

    const/4 v0, 0x0

    .line 488
    :try_start_0
    invoke-virtual {p0}, Lcom/calltimer/app/HangupAccessibilityService;->getWindows()Ljava/util/List;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    .line 490
    const-string v2, "A11yHangup"

    const-string v3, "getWindows failed"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-object v1, v0

    :goto_0
    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_4

    .line 493
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move v4, v3

    :cond_0
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/view/accessibility/AccessibilityWindowInfo;

    if-nez v5, :cond_1

    goto :goto_1

    .line 497
    :cond_1
    :try_start_1
    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityWindowInfo;->getRoot()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_2

    :catchall_1
    move-object v5, v0

    :goto_2
    if-nez v5, :cond_2

    goto :goto_1

    .line 501
    :cond_2
    invoke-direct {p0, v5}, Lcom/calltimer/app/HangupAccessibilityService;->pkgMatches(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v6

    if-eqz v6, :cond_0

    .line 503
    invoke-direct {p0, v5}, Lcom/calltimer/app/HangupAccessibilityService;->clickEndNode(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v4

    if-eqz v4, :cond_3

    return v2

    :cond_3
    move v4, v2

    goto :goto_1

    :cond_4
    move v4, v3

    .line 510
    :cond_5
    :try_start_2
    invoke-virtual {p0}, Lcom/calltimer/app/HangupAccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :catchall_2
    if-eqz v0, :cond_6

    .line 513
    invoke-direct {p0, v0}, Lcom/calltimer/app/HangupAccessibilityService;->pkgMatches(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v1

    if-eqz v1, :cond_6

    .line 515
    invoke-direct {p0, v0}, Lcom/calltimer/app/HangupAccessibilityService;->clickEndNode(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v0

    if-eqz v0, :cond_7

    return v2

    :cond_6
    move v2, v4

    :cond_7
    if-eqz v2, :cond_8

    .line 518
    invoke-direct {p0}, Lcom/calltimer/app/HangupAccessibilityService;->tapBottomCenter()Z

    move-result v0

    return v0

    :cond_8
    return v3
.end method

.method private checkToastText(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 7

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lcom/calltimer/app/HangupAccessibilityService;->PKG_HINTS:[Ljava/lang/String;

    const/4 v2, 0x0

    :goto_0
    array-length v3, v1

    if-ge v2, v3, :cond_4

    aget-object v3, v1, v2

    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :goto_1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getClassName()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Toast"

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getText()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v6

    if-lez v6, :cond_4

    const/4 v1, 0x0

    :goto_2
    if-ge v1, v6, :cond_4

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    if-eqz v2, :cond_3

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_4

    :cond_1
    sget-object v3, Lcom/calltimer/app/HangupAccessibilityService;->BUSY_TEXT_HINTS:[Ljava/lang/String;

    const/4 v4, 0x0

    :goto_3
    array-length v5, v3

    if-ge v4, v5, :cond_3

    aget-object v5, v3, v4

    invoke-virtual {v2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_2

    aget-object v5, v3, v4

    sput-object v5, Lcom/calltimer/app/HangupAccessibilityService;->sBusyReason:Ljava/lang/String;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    sput-wide v5, Lcom/calltimer/app/HangupAccessibilityService;->sToastBusy:J

    const-string v5, "[yk] toast busy hit"

    invoke-static {v5}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V

    return-void

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    :cond_3
    :goto_4
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_4
    return-void
.end method

.method private clickEndNode(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .locals 3

    .line 534
    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->HANGUP_ID_HINTS:[Ljava/lang/String;

    const/4 v1, 0x1

    invoke-direct {p0, p1, v0, v1}, Lcom/calltimer/app/HangupAccessibilityService;->findHangupNode(Landroid/view/accessibility/AccessibilityNodeInfo;[Ljava/lang/String;Z)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 535
    invoke-direct {p0, v0}, Lcom/calltimer/app/HangupAccessibilityService;->clickSelfOrParent(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result p1

    return p1

    .line 536
    :cond_0
    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->HANGUP_TEXT_HINTS:[Ljava/lang/String;

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0, v2}, Lcom/calltimer/app/HangupAccessibilityService;->findHangupNode(Landroid/view/accessibility/AccessibilityNodeInfo;[Ljava/lang/String;Z)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 537
    invoke-direct {p0, p1}, Lcom/calltimer/app/HangupAccessibilityService;->clickSelfOrParent(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    move v1, v2

    :goto_0
    return v1
.end method

.method private clickSelfOrParent(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .locals 5

    const/4 v0, 0x0

    move-object v1, p1

    :goto_0
    const/4 v2, 0x5

    .line 577
    const-string v3, "A11yHangup"

    const/16 v4, 0x10

    if-ge v0, v2, :cond_1

    if-eqz v1, :cond_1

    .line 578
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->isClickable()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 579
    invoke-virtual {v1, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    move-result p1

    .line 580
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "click hangup node, result="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 581
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "click hangup node result="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V

    return p1

    .line 584
    :cond_0
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getParent()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v1

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 586
    :cond_1
    invoke-virtual {p1, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    move-result p1

    .line 587
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "click hangup node (self), result="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return p1
.end method

.method private findHangupNode(Landroid/view/accessibility/AccessibilityNodeInfo;[Ljava/lang/String;Z)Landroid/view/accessibility/AccessibilityNodeInfo;
    .locals 4

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    .line 543
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/calltimer/app/HangupAccessibilityService;->hangupMatches(Landroid/view/accessibility/AccessibilityNodeInfo;[Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_1

    return-object p1

    .line 544
    :cond_1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_3

    .line 548
    :try_start_0
    invoke-virtual {p1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-object v3, v0

    .line 551
    :goto_1
    invoke-direct {p0, v3, p2, p3}, Lcom/calltimer/app/HangupAccessibilityService;->findHangupNode(Landroid/view/accessibility/AccessibilityNodeInfo;[Ljava/lang/String;Z)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    if-eqz v3, :cond_2

    return-object v3

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    return-object v0
.end method

.method public static getLogText()Ljava/lang/String;
    .locals 1

    .line 186
    invoke-static {}, Lcom/calltimer/app/Diagnostic;->getText()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private hangupMatches(Landroid/view/accessibility/AccessibilityNodeInfo;[Ljava/lang/String;Z)Z
    .locals 3

    const/4 v0, 0x0

    if-eqz p3, :cond_1

    .line 560
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_0

    return v0

    .line 562
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    goto :goto_1

    .line 564
    :cond_1
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object p3

    .line 565
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object p1

    .line 566
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, ""

    if-eqz p3, :cond_2

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    goto :goto_0

    :cond_2
    move-object p3, v2

    :goto_0
    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    const-string v1, " "

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p3

    if-eqz p1, :cond_3

    .line 567
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_3
    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    .line 569
    :goto_1
    array-length p3, p2

    move v1, v0

    :goto_2
    if-ge v1, p3, :cond_5

    aget-object v2, p2, v1

    .line 570
    invoke-virtual {p1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_4

    const/4 p1, 0x1

    return p1

    :cond_4
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_5
    return v0
.end method

.method public static isReady()Z
    .locals 1

    .line 91
    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sInstance:Lcom/calltimer/app/HangupAccessibilityService;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private isVisible(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .locals 0

    .line 353
    :try_start_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p1

    :catchall_0
    const/4 p1, 0x1

    return p1
.end method

.method private synthetic lambda$onAccessibilityEvent$0(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 3

    const/16 v0, 0x50

    .line 118
    invoke-direct {p0, v0}, Lcom/calltimer/app/HangupAccessibilityService;->scanInternal(I)Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    move-result-object v0

    .line 119
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object p1

    .line 120
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "event pkg="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const-string p1, "?"

    :goto_0
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v1, " c="

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 121
    iget-boolean v1, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v1, " d="

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 122
    iget-boolean v1, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->dialing:Z

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v1, " ui="

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 123
    iget-boolean v1, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->callUiVisible:Z

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v1, " cand="

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    iget-object v1, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->timerCandidates:Ljava/util/List;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    .line 125
    iget-object v1, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->hitText:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v0, ""

    goto :goto_1

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, " hit=\""

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->hitText:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_1
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 120
    invoke-static {p1}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic lambda$requestHangup$1(Lcom/calltimer/app/HangupAccessibilityService;)V
    .locals 2

    .line 431
    iget-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService;->mCurrent:Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;

    if-eqz v0, :cond_0

    iget-object v1, p0, Lcom/calltimer/app/HangupAccessibilityService;->mMain:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 432
    :cond_0
    new-instance v0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;-><init>(Lcom/calltimer/app/HangupAccessibilityService;Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable-IA;)V

    iput-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService;->mCurrent:Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;

    .line 433
    iget-object p0, p0, Lcom/calltimer/app/HangupAccessibilityService;->mMain:Landroid/os/Handler;

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method static synthetic lambda$swipeUpUnlock$2(Lcom/calltimer/app/HangupAccessibilityService;)V
    .locals 10

    .line 442
    const-string v0, "A11yHangup"

    .line 0
    const-string v1, "swipe up unlock dispatched="

    .line 442
    invoke-direct {p0}, Lcom/calltimer/app/HangupAccessibilityService;->wakeScreen()V

    .line 444
    :try_start_0
    invoke-virtual {p0}, Lcom/calltimer/app/HangupAccessibilityService;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    .line 445
    iget v3, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v3, v3

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v3, v4

    .line 446
    new-instance v5, Landroid/graphics/Path;

    invoke-direct {v5}, Landroid/graphics/Path;-><init>()V

    .line 447
    iget v4, v2, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v4, v4

    const v6, 0x3f5c28f6    # 0.86f

    mul-float/2addr v4, v6

    invoke-virtual {v5, v3, v4}, Landroid/graphics/Path;->moveTo(FF)V

    .line 448
    iget v2, v2, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v2, v2

    const v4, 0x3e3851ec    # 0.18f

    mul-float/2addr v2, v4

    invoke-virtual {v5, v3, v2}, Landroid/graphics/Path;->lineTo(FF)V

    .line 449
    new-instance v2, Landroid/accessibilityservice/GestureDescription$StrokeDescription;

    const-wide/16 v6, 0x1e

    const-wide/16 v8, 0xdc

    move-object v4, v2

    invoke-direct/range {v4 .. v9}, Landroid/accessibilityservice/GestureDescription$StrokeDescription;-><init>(Landroid/graphics/Path;JJ)V

    .line 451
    new-instance v3, Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-direct {v3}, Landroid/accessibilityservice/GestureDescription$Builder;-><init>()V

    .line 452
    invoke-virtual {v3, v2}, Landroid/accessibilityservice/GestureDescription$Builder;->addStroke(Landroid/accessibilityservice/GestureDescription$StrokeDescription;)Landroid/accessibilityservice/GestureDescription$Builder;

    move-result-object v2

    invoke-virtual {v2}, Landroid/accessibilityservice/GestureDescription$Builder;->build()Landroid/accessibilityservice/GestureDescription;

    move-result-object v2

    const/4 v3, 0x0

    .line 453
    invoke-virtual {p0, v2, v3, v3}, Lcom/calltimer/app/HangupAccessibilityService;->dispatchGesture(Landroid/accessibilityservice/GestureDescription;Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;Landroid/os/Handler;)Z

    move-result p0

    .line 454
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 455
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    .line 457
    const-string v1, "swipe up unlock failed"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    return-void
.end method

.method public static log(Ljava/lang/String;)V
    .locals 2

    .line 190
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "[a11y] "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    return-void
.end method

.method private pkgMatches(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .locals 5

    .line 523
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    .line 525
    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    .line 526
    const-string v1, "calltimer"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    return v0

    .line 527
    :cond_1
    sget-object v1, Lcom/calltimer/app/HangupAccessibilityService;->PKG_HINTS:[Ljava/lang/String;

    array-length v2, v1

    move v3, v0

    :goto_0
    if-ge v3, v2, :cond_3

    aget-object v4, v1, v3

    .line 528
    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/4 p1, 0x1

    return p1

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    return v0
.end method

.method private remarkHit(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 8

    if-eqz p1, :cond_8

    sget-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkHit:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkSeen:Ljava/util/HashSet;

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-direct {p0, p1}, Lcom/calltimer/app/HangupAccessibilityService;->isVisible(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v0

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v2

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_1
    const-string v1, ""

    :goto_0
    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    :cond_2
    const-string v2, ""

    :goto_1
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    if-eqz v0, :cond_6

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6

    const-string v0, "\u884c\u653f"

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_3

    const-string v0, "\u9000\u4f11"

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    :cond_3
    if-eqz v0, :cond_5

    sget-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkLabel:Z

    if-nez v0, :cond_4

    const-string v0, "\u5ba2\u6237\u5907\u6ce8"

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_2

    :cond_4
    const/4 v0, 0x1

    sput-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkHit:Z

    const-string v0, "[yk] remark hit"

    invoke-static {v0}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V

    return-void

    :cond_5
    const-string v0, "\u5ba2\u6237\u5907\u6ce8"

    invoke-virtual {v3, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    sput-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkLabel:Z

    :cond_6
    :goto_2
    sget-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkHit:Z

    if-nez v0, :cond_8

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_3
    if-ge v1, v0, :cond_8

    invoke-virtual {p1, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v2

    if-eqz v2, :cond_7

    invoke-direct {p0, v2}, Lcom/calltimer/app/HangupAccessibilityService;->remarkHit(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    :cond_7
    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_8
    return-void
.end method

.method private remarkScan(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .locals 5

    const/4 v0, 0x0

    return v0

    const/4 v0, 0x0

    sput-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkHit:Z

    sput-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkLabel:Z

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    sput-object v1, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkSeen:Ljava/util/HashSet;

    invoke-direct {p0, p1}, Lcom/calltimer/app/HangupAccessibilityService;->remarkHit(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    sget-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkHit:Z

    if-nez v0, :cond_0

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkFirst:J

    const/4 v0, 0x0

    return v0

    :cond_0
    sget-wide v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkFirst:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-nez v4, :cond_1

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    sput-wide v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkFirst:J

    const/4 v0, 0x0

    sput-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkHit:Z

    const/4 v0, 0x0

    return v0

    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    sget-wide v2, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkFirst:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x4b0

    cmp-long v4, v0, v2

    if-ltz v4, :cond_3

    const-wide/16 v2, 0xbb8

    cmp-long v4, v0, v2

    if-lez v4, :cond_2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    sput-wide v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkFirst:J

    const/4 v0, 0x0

    sput-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkHit:Z

    const/4 v0, 0x0

    return v0

    :cond_2
    const/4 v0, 0x1

    return v0

    :cond_3
    const/4 v0, 0x0

    sput-boolean v0, Lcom/calltimer/app/HangupAccessibilityService;->sRemarkHit:Z

    const/4 v0, 0x0

    return v0
.end method

.method public static requestHangup()V
    .locals 3

    .line 425
    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sInstance:Lcom/calltimer/app/HangupAccessibilityService;

    if-nez v0, :cond_0

    .line 427
    const-string v0, "A11yHangup"

    const-string v1, "accessibility service not enabled, skip"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 430
    :cond_0
    iget-object v1, v0, Lcom/calltimer/app/HangupAccessibilityService;->mMain:Landroid/os/Handler;

    new-instance v2, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0}, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda1;-><init>(Lcom/calltimer/app/HangupAccessibilityService;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static resetWatch()V
    .locals 1

    .line 96
    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sWatch:Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;

    invoke-virtual {v0}, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->reset()V

    return-void
.end method

.method private scanInternal(I)Lcom/calltimer/app/HangupAccessibilityService$ScanResult;
    .locals 11

    .line 194
    new-instance v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    invoke-direct {v6}, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;-><init>()V

    .line 195
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 196
    new-instance v8, Ljava/util/LinkedHashSet;

    invoke-direct {v8}, Ljava/util/LinkedHashSet;-><init>()V

    .line 197
    filled-new-array {p1}, [I

    move-result-object p1

    const/4 v9, 0x0

    .line 201
    :try_start_0
    invoke-virtual {p0}, Lcom/calltimer/app/HangupAccessibilityService;->getWindows()Ljava/util/List;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    .line 203
    const-string v1, "A11yHangup"

    const-string v2, "getWindows failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-object v0, v9

    :goto_0
    if-eqz v0, :cond_3

    .line 206
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_1
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/accessibility/AccessibilityWindowInfo;

    if-nez v0, :cond_0

    goto :goto_1

    .line 210
    :cond_0
    :try_start_1
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityWindowInfo;->getRoot()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    move-object v1, v0

    goto :goto_2

    :catchall_1
    move-object v1, v9

    :goto_2
    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "yunke"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_1

    :cond_2
    move-object v0, p0

    move-object v2, v6

    move-object v3, v7

    move-object v4, v8

    move-object v5, p1

    .line 214
    invoke-direct/range {v0 .. v5}, Lcom/calltimer/app/HangupAccessibilityService;->scanTree(Landroid/view/accessibility/AccessibilityNodeInfo;Lcom/calltimer/app/HangupAccessibilityService$ScanResult;Ljava/util/List;Ljava/util/Set;[I)V

    goto :goto_1

    .line 219
    :cond_3
    :try_start_2
    invoke-virtual {p0}, Lcom/calltimer/app/HangupAccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    move-object v1, v0

    goto :goto_3

    :catchall_2
    move-object v1, v9

    :goto_3
    if-eqz v1, :cond_6

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "yunke"

    invoke-virtual {v0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_5

    :cond_4
    move-object v0, p0

    move-object v2, v6

    move-object v3, v7

    move-object v4, v8

    move-object v5, p1

    .line 223
    invoke-direct/range {v0 .. v5}, Lcom/calltimer/app/HangupAccessibilityService;->scanTree(Landroid/view/accessibility/AccessibilityNodeInfo;Lcom/calltimer/app/HangupAccessibilityService$ScanResult;Ljava/util/List;Ljava/util/Set;[I)V

    goto :goto_4

    :cond_5
    invoke-direct {p0, v1}, Lcom/calltimer/app/HangupAccessibilityService;->remarkScan(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 226
    :cond_6
    :goto_4
    sget-wide v2, Lcom/calltimer/app/HangupAccessibilityService;->sToastBusy:J

    const-wide/16 v0, 0x0

    cmp-long v4, v2, v0

    if-lez v4, :cond_7

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x7d0

    cmp-long v4, v0, v2

    if-ltz v4, :cond_7

    const-wide/16 v2, 0x1f40

    cmp-long v4, v0, v2

    if-gez v4, :cond_7

    const/4 v0, 0x1

    iput-boolean v0, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->busy:Z

    :cond_7
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1, v8}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object p1, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->timerCandidates:Ljava/util/List;

    .line 227
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 228
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, " "

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "-"

    invoke-virtual {v2, v3, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "\\+?\\d{7,15}"

    invoke-virtual {v2, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_8

    sput-object v2, Lcom/calltimer/app/HangupAccessibilityService;->sCallNumber:Ljava/lang/String;

    .line 229
    :cond_8
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    if-lez v2, :cond_9

    const/16 v2, 0x2c

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 230
    :cond_9
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_5

    .line 232
    :cond_a
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->packages:Ljava/lang/String;

    .line 235
    iget-boolean p1, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    if-nez p1, :cond_b

    sget-object p1, Lcom/calltimer/app/HangupAccessibilityService;->sWatch:Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    invoke-virtual {p1, v8, v0, v1}, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->update(Ljava/util/Collection;J)Z

    move-result v0

    if-eqz v0, :cond_b

    iget-boolean v0, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->dialing:Z

    if-nez v0, :cond_b

    const/4 v0, 0x1

    .line 236
    iput-boolean v0, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    .line 237
    const-string v0, "timerRunning"

    iput-object v0, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->reason:Ljava/lang/String;

    .line 238
    invoke-virtual {p1}, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->evidence()Ljava/lang/String;

    move-result-object p1

    iput-object p1, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->hitText:Ljava/lang/String;

    .line 240
    :cond_b
    sget-object p1, Lcom/calltimer/app/HangupAccessibilityService;->sWatch:Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;

    invoke-virtual {p1}, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->isConfirmed()Z

    move-result p1

    iput-boolean p1, v6, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->watchConfirmed:Z

    return-object v6
.end method

.method public static scanNow()Lcom/calltimer/app/HangupAccessibilityService$ScanResult;
    .locals 4

    .line 173
    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sInstance:Lcom/calltimer/app/HangupAccessibilityService;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    const/16 v1, 0x190

    .line 176
    :try_start_0
    invoke-direct {v0, v1}, Lcom/calltimer/app/HangupAccessibilityService;->scanInternal(I)Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v0

    :catchall_0
    move-exception v0

    .line 178
    const-string v1, "A11yHangup"

    const-string v2, "scan error"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 179
    new-instance v1, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    invoke-direct {v1}, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;-><init>()V

    .line 180
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "error:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->reason:Ljava/lang/String;

    return-object v1
.end method

.method private scanTree(Landroid/view/accessibility/AccessibilityNodeInfo;Lcom/calltimer/app/HangupAccessibilityService$ScanResult;Ljava/util/List;Ljava/util/Set;[I)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/accessibility/AccessibilityNodeInfo;",
            "Lcom/calltimer/app/HangupAccessibilityService$ScanResult;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;[I)V"
        }
    .end annotation

    .line 246
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 247
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const-string v0, ""

    .line 248
    :goto_0
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-interface {p3, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    invoke-interface {p3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 254
    :cond_1
    const-string p3, "calltimer"

    invoke-virtual {v0, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p3

    if-nez p3, :cond_4

    .line 255
    sget-object p3, Lcom/calltimer/app/HangupAccessibilityService;->PKG_HINTS:[Ljava/lang/String;

    array-length v1, p3

    const/4 v2, 0x0

    move v3, v2

    :goto_1
    if-ge v3, v1, :cond_4

    aget-object v4, p3, v3

    .line 256
    invoke-virtual {v0, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_3

    const/4 p3, 0x1

    .line 261
    new-array v0, p3, [Z

    aput-boolean p3, v0, v2

    move-object v3, p0

    move-object v4, p1

    move-object v5, p2

    move-object v6, v0

    move-object v7, p4

    move-object v8, p5

    .line 262
    invoke-direct/range {v3 .. v8}, Lcom/calltimer/app/HangupAccessibilityService;->walk(Landroid/view/accessibility/AccessibilityNodeInfo;Lcom/calltimer/app/HangupAccessibilityService$ScanResult;[ZLjava/util/Set;[I)V

    .line 263
    aget-boolean p1, v0, v2

    if-eqz p1, :cond_2

    iput-boolean p3, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->callUiVisible:Z

    :cond_2
    return-void

    :cond_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_4
    return-void
.end method

.method public static swipeUpUnlock()V
    .locals 3

    .line 439
    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sInstance:Lcom/calltimer/app/HangupAccessibilityService;

    if-nez v0, :cond_0

    return-void

    .line 441
    :cond_0
    iget-object v1, v0, Lcom/calltimer/app/HangupAccessibilityService;->mMain:Landroid/os/Handler;

    new-instance v2, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda0;

    invoke-direct {v2, v0}, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda0;-><init>(Lcom/calltimer/app/HangupAccessibilityService;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private tapBottomCenter()Z
    .locals 11

    .line 593
    const-string v0, "A11yHangup"

    .line 0
    const-string v1, "fallback tap dispatched="

    const-string v2, "fallback gesture tap, dispatched="

    .line 593
    :try_start_0
    invoke-virtual {p0}, Lcom/calltimer/app/HangupAccessibilityService;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    .line 594
    iget v4, v3, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v4, v4

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    .line 595
    iget v3, v3, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v3, v3

    const v5, 0x3f6147ae    # 0.88f

    mul-float/2addr v3, v5

    .line 596
    new-instance v6, Landroid/graphics/Path;

    invoke-direct {v6}, Landroid/graphics/Path;-><init>()V

    .line 597
    invoke-virtual {v6, v4, v3}, Landroid/graphics/Path;->moveTo(FF)V

    .line 598
    new-instance v3, Landroid/accessibilityservice/GestureDescription$StrokeDescription;

    const-wide/16 v7, 0x0

    const-wide/16 v9, 0x32

    move-object v5, v3

    invoke-direct/range {v5 .. v10}, Landroid/accessibilityservice/GestureDescription$StrokeDescription;-><init>(Landroid/graphics/Path;JJ)V

    .line 600
    new-instance v4, Landroid/accessibilityservice/GestureDescription$Builder;

    invoke-direct {v4}, Landroid/accessibilityservice/GestureDescription$Builder;-><init>()V

    .line 601
    invoke-virtual {v4, v3}, Landroid/accessibilityservice/GestureDescription$Builder;->addStroke(Landroid/accessibilityservice/GestureDescription$StrokeDescription;)Landroid/accessibilityservice/GestureDescription$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/accessibilityservice/GestureDescription$Builder;->build()Landroid/accessibilityservice/GestureDescription;

    move-result-object v3

    const/4 v4, 0x0

    .line 602
    invoke-virtual {p0, v3, v4, v4}, Lcom/calltimer/app/HangupAccessibilityService;->dispatchGesture(Landroid/accessibilityservice/GestureDescription;Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;Landroid/os/Handler;)Z

    move-result v3

    .line 603
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 604
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return v3

    :catchall_0
    move-exception v1

    .line 607
    const-string v2, "gesture tap failed"

    invoke-static {v0, v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v0, 0x0

    return v0
.end method

.method private wakeScreen()V
    .locals 3

    .line 615
    :try_start_0
    const-string v0, "power"

    invoke-virtual {p0, v0}, Lcom/calltimer/app/HangupAccessibilityService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    if-eqz v0, :cond_0

    .line 616
    invoke-virtual {v0}, Landroid/os/PowerManager;->isInteractive()Z

    move-result v1

    if-nez v1, :cond_0

    .line 617
    const-string v1, "calltimer:wake"

    const v2, 0x3000000a

    invoke-virtual {v0, v2, v1}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v0

    const-wide/16 v1, 0xbb8

    .line 622
    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager$WakeLock;->acquire(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    .line 625
    const-string v1, "A11yHangup"

    const-string v2, "wakeScreen failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    :goto_0
    return-void
.end method

.method private walk(Landroid/view/accessibility/AccessibilityNodeInfo;Lcom/calltimer/app/HangupAccessibilityService$ScanResult;[ZLjava/util/Set;[I)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/accessibility/AccessibilityNodeInfo;",
            "Lcom/calltimer/app/HangupAccessibilityService$ScanResult;",
            "[Z",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;[I)V"
        }
    .end annotation

    if-eqz p1, :cond_12

    const/4 v0, 0x0

    .line 268
    aget v1, p5, v0

    if-gtz v1, :cond_0

    goto/16 :goto_10

    :cond_0
    const/4 v2, 0x1

    sub-int/2addr v1, v2

    .line 269
    aput v1, p5, v0

    .line 271
    invoke-direct {p0, p1}, Lcom/calltimer/app/HangupAccessibilityService;->isVisible(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v1

    .line 272
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getViewIdResourceName()Ljava/lang/String;

    move-result-object v3

    .line 273
    const-string v4, ""

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    goto :goto_0

    :cond_1
    move-object v3, v4

    .line 274
    :goto_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v5

    .line 275
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v6

    if-eqz v5, :cond_2

    .line 276
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    goto :goto_1

    :cond_2
    move-object v5, v4

    :goto_1
    if-eqz v6, :cond_3

    .line 277
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    .line 278
    :cond_3
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    .line 281
    sget-object v6, Lcom/calltimer/app/HangupAccessibilityService;->CALL_UI_TEXT_HINTS:[Ljava/lang/String;

    array-length v7, v6

    move v8, v0

    :goto_2
    if-ge v8, v7, :cond_5

    aget-object v9, v6, v8

    .line 282
    invoke-virtual {v9}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_4

    aput-boolean v2, p3, v0

    goto :goto_3

    :cond_4
    add-int/lit8 v8, v8, 0x1

    goto :goto_2

    .line 286
    :cond_5
    :goto_3
    sget-object v6, Lcom/calltimer/app/HangupAccessibilityService;->DIALING_TEXT_HINTS:[Ljava/lang/String;

    array-length v7, v6

    move v8, v0

    :goto_4
    if-ge v8, v7, :cond_7

    aget-object v9, v6, v8

    .line 287
    invoke-virtual {v4, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_6

    .line 289
    iput-boolean v2, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->dialing:Z

    goto :goto_5

    :cond_6
    add-int/lit8 v8, v8, 0x1

    goto :goto_4

    .line 292
    :cond_7
    :goto_5
    sget-object v6, Lcom/calltimer/app/HangupAccessibilityService;->BUSY_TEXT_HINTS:[Ljava/lang/String;

    array-length v7, v6

    move v8, v0

    :goto_6
    if-ge v8, v7, :cond_9

    aget-object v9, v6, v8

    .line 293
    invoke-virtual {v4, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_8

    .line 294
    iput-boolean v2, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->busy:Z

    goto :goto_7

    :cond_8
    add-int/lit8 v8, v8, 0x1

    goto :goto_6

    :cond_9
    :goto_7
    move v6, v0

    if-eqz v6, :cond_a

    .line 295
    iput-boolean v2, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->busy:Z

    :cond_a
    if-eqz v1, :cond_11

    if-nez v6, :cond_11

    .line 299
    iget-boolean v1, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    if-nez v1, :cond_d

    .line 300
    sget-object v1, Lcom/calltimer/app/HangupAccessibilityService;->CONNECTED_TEXT_HINTS:[Ljava/lang/String;

    array-length v6, v1

    move v7, v0

    :goto_8
    if-ge v7, v6, :cond_c

    aget-object v8, v1, v7

    .line 301
    invoke-virtual {v4, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v9

    if-eqz v9, :cond_b

    .line 302
    iput-boolean v2, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    .line 303
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v6, "text:"

    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->reason:Ljava/lang/String;

    .line 304
    iput-object v5, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->hitText:Ljava/lang/String;

    goto :goto_9

    :cond_b
    add-int/lit8 v7, v7, 0x1

    goto :goto_8

    .line 309
    :cond_c
    :goto_9
    iget-boolean v1, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    if-nez v1, :cond_d

    const-string v1, "\u901a\u8bdd\u4e2d"

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_d

    const-string v1, "\u6b63\u5728\u901a\u8bdd\u4e2d"

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_d

    const-string v1, "\u901a\u8bdd\u4e2d\uff0c\u8bf7"

    .line 310
    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_d

    const-string v1, "\u901a\u8bdd\u4e2d,"

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_d

    .line 311
    iput-boolean v2, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    .line 312
    const-string v1, "text:\u901a\u8bdd\u4e2d"

    iput-object v1, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->reason:Ljava/lang/String;

    .line 313
    iput-object v5, p2, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->hitText:Ljava/lang/String;

    .line 318
    :cond_d
    aget-boolean v1, p3, v0

    if-eqz v1, :cond_11

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_11

    .line 319
    sget-object v1, Lcom/calltimer/app/HangupAccessibilityService;->TIMER_TEXT_EXACT:Ljava/util/regex/Pattern;

    invoke-virtual {v1, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    .line 320
    invoke-virtual {v1}, Ljava/util/regex/Matcher;->matches()Z

    move-result v1

    const-string v4, "00:00"

    const-string v6, "0:00"

    if-eqz v1, :cond_e

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    .line 321
    invoke-interface {p4, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_a

    .line 323
    :cond_e
    sget-object v1, Lcom/calltimer/app/HangupAccessibilityService;->TIMER_TEXT_EMBED:Ljava/util/regex/Pattern;

    invoke-virtual {v1, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    .line 324
    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v7

    if-eqz v7, :cond_f

    invoke-virtual {v1, v2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p4, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 327
    :cond_f
    :goto_a
    sget-object v1, Lcom/calltimer/app/HangupAccessibilityService;->TIMER_ID_HINTS:[Ljava/lang/String;

    array-length v2, v1

    move v7, v0

    :goto_b
    if-ge v7, v2, :cond_11

    aget-object v8, v1, v7

    .line 328
    invoke-virtual {v3, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_10

    .line 331
    const-string v1, "\\d{1,2}:[0-5]\\d"

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    .line 332
    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    if-eqz v2, :cond_11

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_11

    .line 333
    invoke-virtual {v1}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_11

    .line 334
    invoke-virtual {v1}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p4, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_c

    :cond_10
    add-int/lit8 v7, v7, 0x1

    goto :goto_b

    .line 340
    :cond_11
    :goto_c
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v1

    move v2, v0

    :goto_d
    if-ge v2, v1, :cond_12

    .line 341
    aget v3, p5, v0

    if-lez v3, :cond_12

    .line 344
    :try_start_0
    invoke-virtual {p1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_e
    move-object v5, v3

    goto :goto_f

    :catchall_0
    const/4 v3, 0x0

    goto :goto_e

    :goto_f
    move-object v4, p0

    move-object v6, p2

    move-object v7, p3

    move-object v8, p4

    move-object v9, p5

    .line 347
    invoke-direct/range {v4 .. v9}, Lcom/calltimer/app/HangupAccessibilityService;->walk(Landroid/view/accessibility/AccessibilityNodeInfo;Lcom/calltimer/app/HangupAccessibilityService$ScanResult;[ZLjava/util/Set;[I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_d

    :cond_12
    :goto_10
    return-void
.end method

.method public static ykIsAlive()Z
    .locals 1

    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sInstance:Lcom/calltimer/app/HangupAccessibilityService;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public static ykResetToast()V
    .locals 2

    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/calltimer/app/HangupAccessibilityService;->sToastBusy:J

    const/4 v0, 0x0

    sput-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sBusyReason:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 6

    invoke-static {p0, p1}, Lcom/calltimer/app/YkAutoFix;->handle(Landroid/accessibilityservice/AccessibilityService;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 109
    sget-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sInstance:Lcom/calltimer/app/HangupAccessibilityService;

    if-nez v0, :cond_0

    return-void

    .line 110
    :cond_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v0

    const/16 v1, 0x40

    if-eq v0, v1, :cond_2

    const v1, 0x10000

    if-eq v0, v1, :cond_2

    const/16 v1, 0x20

    if-eq v0, v1, :cond_1

    const/16 v1, 0x800

    if-eq v0, v1, :cond_1

    const/high16 v1, 0x400000

    if-ne v0, v1, :cond_3

    .line 114
    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 115
    iget-wide v2, p0, Lcom/calltimer/app/HangupAccessibilityService;->mLastEventScan:J

    sub-long v2, v0, v2

    const-wide/16 v4, 0x190

    cmp-long v2, v2, v4

    if-lez v2, :cond_3

    .line 116
    iput-wide v0, p0, Lcom/calltimer/app/HangupAccessibilityService;->mLastEventScan:J

    .line 117
    iget-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService;->mMain:Landroid/os/Handler;

    new-instance v1, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p1}, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda2;-><init>(Lcom/calltimer/app/HangupAccessibilityService;Landroid/view/accessibility/AccessibilityEvent;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    invoke-direct {p0, p1}, Lcom/calltimer/app/HangupAccessibilityService;->checkToastText(Landroid/view/accessibility/AccessibilityEvent;)V

    return-void

    :cond_3
    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 137
    const-string v0, "service destroyed"

    invoke-static {v0}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V

    invoke-static {}, Lcom/calltimer/app/YkOverlay;->hide()V

    const/4 v0, 0x0

    .line 138
    sput-object v0, Lcom/calltimer/app/HangupAccessibilityService;->sInstance:Lcom/calltimer/app/HangupAccessibilityService;

    .line 139
    invoke-super {p0}, Landroid/accessibilityservice/AccessibilityService;->onDestroy()V

    return-void
.end method

.method public onInterrupt()V
    .locals 0

    return-void
.end method

.method protected onServiceConnected()V
    .locals 2

    .line 101
    invoke-super {p0}, Landroid/accessibilityservice/AccessibilityService;->onServiceConnected()V

    .line 102
    sput-object p0, Lcom/calltimer/app/HangupAccessibilityService;->sInstance:Lcom/calltimer/app/HangupAccessibilityService;

    .line 103
    const-string v0, "service connected"

    invoke-static {v0}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V

    .line 104
    const-string v0, "A11yHangup"

    const-string v1, "accessibility service connected"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {p0}, Lcom/calltimer/app/YkOverlay;->show(Landroid/content/Context;)V

    return-void
.end method
