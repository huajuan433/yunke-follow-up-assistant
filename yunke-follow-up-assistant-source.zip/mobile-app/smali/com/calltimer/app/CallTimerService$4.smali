.class Lcom/calltimer/app/CallTimerService$4;
.super Ljava/lang/Object;
.source "CallTimerService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/CallTimerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/CallTimerService;


# direct methods
.method constructor <init>(Lcom/calltimer/app/CallTimerService;)V
    .locals 0

    .line 138
    iput-object p1, p0, Lcom/calltimer/app/CallTimerService$4;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 141
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$4;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmPhase(Lcom/calltimer/app/CallTimerService;)Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v0

    sget-object v1, Lcom/calltimer/app/CallTimerService$Phase;->WAITING:Lcom/calltimer/app/CallTimerService$Phase;

    if-eq v0, v1, :cond_0

    return-void

    .line 142
    :cond_0
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$4;->this$0:Lcom/calltimer/app/CallTimerService;

    const-string v1, "notification"

    invoke-virtual {v0, v1}, Lcom/calltimer/app/CallTimerService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    if-eqz v0, :cond_1

    .line 143
    iget-object v1, p0, Lcom/calltimer/app/CallTimerService$4;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v1}, Lcom/calltimer/app/CallTimerService;->-$$Nest$mbuildNotification(Lcom/calltimer/app/CallTimerService;)Landroid/app/Notification;

    move-result-object v1

    const/16 v2, 0x3e9

    invoke-virtual {v0, v2, v1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 144
    :cond_1
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$4;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmMain(Lcom/calltimer/app/CallTimerService;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x3e8

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
