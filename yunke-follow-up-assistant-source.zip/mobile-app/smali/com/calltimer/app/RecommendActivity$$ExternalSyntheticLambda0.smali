.class public final synthetic Lcom/calltimer/app/RecommendActivity$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/calltimer/app/RecommendActivity;

.field public final synthetic f$1:Lcom/calltimer/app/WaitStatsAnalyzer$Row;


# direct methods
.method public synthetic constructor <init>(Lcom/calltimer/app/RecommendActivity;Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/calltimer/app/RecommendActivity$$ExternalSyntheticLambda0;->f$0:Lcom/calltimer/app/RecommendActivity;

    iput-object p2, p0, Lcom/calltimer/app/RecommendActivity$$ExternalSyntheticLambda0;->f$1:Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/calltimer/app/RecommendActivity$$ExternalSyntheticLambda0;->f$0:Lcom/calltimer/app/RecommendActivity;

    iget-object v1, p0, Lcom/calltimer/app/RecommendActivity$$ExternalSyntheticLambda0;->f$1:Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    invoke-static {v0, v1, p1}, Lcom/calltimer/app/RecommendActivity;->$r8$lambda$_qrFWoEPhkNV8jFFzGYcwFbT8nY(Lcom/calltimer/app/RecommendActivity;Lcom/calltimer/app/WaitStatsAnalyzer$Row;Landroid/view/View;)V

    return-void
.end method
