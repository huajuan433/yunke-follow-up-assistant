.class Lcom/calltimer/app/CallTimerService$5;
.super Ljava/lang/Object;
.source "CallTimerService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/CallTimerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/CallTimerService;


# direct methods
.method constructor <init>(Lcom/calltimer/app/CallTimerService;)V
    .locals 0

    .line 153
    iput-object p1, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    .line 157
    const-string v0, ", force reset"

    const-string v1, "reconcile: OFFHOOK while not armed, skip this call"

    const-string v2, "reconcile: missed OFFHOOK event, recovering"

    const-string v3, "CallTimerService"

    .line 0
    const-string v4, "reconcile: physical IDLE but phase="

    .line 157
    :try_start_0
    iget-object v5, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v5}, Lcom/calltimer/app/CallTimerService;->-$$Nest$mreadCallState(Lcom/calltimer/app/CallTimerService;)I

    move-result v5

    const/4 v6, 0x1

    if-nez v5, :cond_2

    .line 159
    iget-object v1, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v1, v6}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fputmArmed(Lcom/calltimer/app/CallTimerService;Z)V

    .line 160
    iget-object v1, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v1}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmPhase(Lcom/calltimer/app/CallTimerService;)Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v1

    sget-object v2, Lcom/calltimer/app/CallTimerService$Phase;->IDLE:Lcom/calltimer/app/CallTimerService$Phase;

    if-eq v1, v2, :cond_0

    .line 161
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v2}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmPhase(Lcom/calltimer/app/CallTimerService;)Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 162
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v2}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmPhase(Lcom/calltimer/app/CallTimerService;)Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 163
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$monIdle(Lcom/calltimer/app/CallTimerService;)V

    .line 166
    :cond_0
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/Prefs;->isEnabled(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 167
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->isReady()Z

    move-result v0

    if-nez v0, :cond_1

    .line 168
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmA11yWarned(Lcom/calltimer/app/CallTimerService;)Z

    move-result v0

    if-nez v0, :cond_5

    .line 169
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0, v6}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fputmA11yWarned(Lcom/calltimer/app/CallTimerService;Z)V

    .line 170
    const-string v0, "accessibility OFFLINE detected, warning shown"

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 171
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$mnotifyA11yWarning(Lcom/calltimer/app/CallTimerService;)V

    goto :goto_0

    .line 174
    :cond_1
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fputmA11yWarned(Lcom/calltimer/app/CallTimerService;Z)V

    goto :goto_0

    :cond_2
    if-ne v5, v6, :cond_3

    .line 178
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0, v6}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fputmSawRinging(Lcom/calltimer/app/CallTimerService;Z)V

    goto :goto_0

    :cond_3
    const/4 v0, 0x2

    if-ne v5, v0, :cond_5

    .line 180
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmPhase(Lcom/calltimer/app/CallTimerService;)Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v0

    sget-object v4, Lcom/calltimer/app/CallTimerService$Phase;->IDLE:Lcom/calltimer/app/CallTimerService$Phase;

    if-ne v0, v4, :cond_5

    .line 181
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmArmed(Lcom/calltimer/app/CallTimerService;)Z

    move-result v0

    if-nez v0, :cond_4

    .line 183
    invoke-static {v3, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 184
    invoke-static {v1}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 185
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    sget-object v1, Lcom/calltimer/app/CallTimerService$Phase;->CONNECTED:Lcom/calltimer/app/CallTimerService$Phase;

    invoke-static {v0, v1}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fputmPhase(Lcom/calltimer/app/CallTimerService;Lcom/calltimer/app/CallTimerService$Phase;)V

    .line 186
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$mrefreshNotification(Lcom/calltimer/app/CallTimerService;)V

    goto :goto_0

    .line 188
    :cond_4
    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 189
    invoke-static {v2}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 190
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$monOffhook(Lcom/calltimer/app/CallTimerService;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    .line 195
    const-string v1, "reconcile failed"

    invoke-static {v3, v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 197
    :cond_5
    :goto_0
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$5;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmMain(Lcom/calltimer/app/CallTimerService;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x3e8

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
