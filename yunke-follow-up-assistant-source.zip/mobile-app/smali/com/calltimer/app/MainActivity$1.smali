.class Lcom/calltimer/app/MainActivity$1;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/calltimer/app/MainActivity;)V
    .locals 0

    .line 38
    iput-object p1, p0, Lcom/calltimer/app/MainActivity$1;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 41
    iget-object v0, p0, Lcom/calltimer/app/MainActivity$1;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-static {v0}, Lcom/calltimer/app/MainActivity;->-$$Nest$mreadSeconds(Lcom/calltimer/app/MainActivity;)Ljava/lang/Integer;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 42
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v2, 0x1

    if-lt v1, v2, :cond_0

    .line 43
    iget-object v1, p0, Lcom/calltimer/app/MainActivity$1;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v1, v0}, Lcom/calltimer/app/Prefs;->setSeconds(Landroid/content/Context;I)V

    .line 44
    iget-object v0, p0, Lcom/calltimer/app/MainActivity$1;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-static {v0}, Lcom/calltimer/app/MainActivity;->-$$Nest$mrefreshService(Lcom/calltimer/app/MainActivity;)V

    .line 45
    iget-object v0, p0, Lcom/calltimer/app/MainActivity$1;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-static {v0}, Lcom/calltimer/app/MainActivity;->-$$Nest$mrefreshStatus(Lcom/calltimer/app/MainActivity;)V

    :cond_0
    return-void
.end method
