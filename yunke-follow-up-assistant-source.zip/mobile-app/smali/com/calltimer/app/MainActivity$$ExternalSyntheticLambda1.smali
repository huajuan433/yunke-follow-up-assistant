.class public final synthetic Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic f$0:Lcom/calltimer/app/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/calltimer/app/MainActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda1;->f$0:Lcom/calltimer/app/MainActivity;

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/calltimer/app/MainActivity$$ExternalSyntheticLambda1;->f$0:Lcom/calltimer/app/MainActivity;

    invoke-static {v0, p1, p2}, Lcom/calltimer/app/MainActivity;->$r8$lambda$gp9529Xhfe-0Iti2qyvOY4x59oA(Lcom/calltimer/app/MainActivity;Landroid/widget/CompoundButton;Z)V

    return-void
.end method
