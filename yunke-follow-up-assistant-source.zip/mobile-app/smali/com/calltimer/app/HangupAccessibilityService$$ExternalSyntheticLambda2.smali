.class public final synthetic Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/calltimer/app/HangupAccessibilityService;

.field public final synthetic f$1:Landroid/view/accessibility/AccessibilityEvent;


# direct methods
.method public synthetic constructor <init>(Lcom/calltimer/app/HangupAccessibilityService;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda2;->f$0:Lcom/calltimer/app/HangupAccessibilityService;

    iput-object p2, p0, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda2;->f$1:Landroid/view/accessibility/AccessibilityEvent;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda2;->f$0:Lcom/calltimer/app/HangupAccessibilityService;

    iget-object v1, p0, Lcom/calltimer/app/HangupAccessibilityService$$ExternalSyntheticLambda2;->f$1:Landroid/view/accessibility/AccessibilityEvent;

    invoke-static {v0, v1}, Lcom/calltimer/app/HangupAccessibilityService;->$r8$lambda$WygMJnM_L-Gr7-q74_y09EBRFwc(Lcom/calltimer/app/HangupAccessibilityService;Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method
