.class interface abstract Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;
.super Ljava/lang/Object;
.source "Api31TelephonyCallback.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/Api31TelephonyCallback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "CallStateHandler"
.end annotation


# virtual methods
.method public abstract onState(I)V
.end method
