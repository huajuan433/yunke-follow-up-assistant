.class public final Lcom/calltimer/app/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/calltimer/app/R$color;,
        Lcom/calltimer/app/R$drawable;,
        Lcom/calltimer/app/R$id;,
        Lcom/calltimer/app/R$layout;,
        Lcom/calltimer/app/R$mipmap;,
        Lcom/calltimer/app/R$string;,
        Lcom/calltimer/app/R$style;,
        Lcom/calltimer/app/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
