.class Lcom/calltimer/app/CallTimerService$1;
.super Ljava/lang/Object;
.source "CallTimerService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/CallTimerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/CallTimerService;


# direct methods
.method constructor <init>(Lcom/calltimer/app/CallTimerService;)V
    .locals 0

    .line 82
    iput-object p1, p0, Lcom/calltimer/app/CallTimerService$1;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 85
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$1;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$monTimeout(Lcom/calltimer/app/CallTimerService;)V

    return-void
.end method
