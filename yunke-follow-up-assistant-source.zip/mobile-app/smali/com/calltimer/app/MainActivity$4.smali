.class Lcom/calltimer/app/MainActivity$4;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/calltimer/app/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/calltimer/app/MainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/calltimer/app/MainActivity$4;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 1

    iget-object v0, p0, Lcom/calltimer/app/MainActivity$4;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-virtual {v0, p1, p2}, Lcom/calltimer/app/MainActivity;->onOverlayOnTopToggle(Landroid/widget/CompoundButton;Z)V

    return-void
.end method
