.class public final Lcom/calltimer/app/HangupController;
.super Ljava/lang/Object;
.source "HangupController.java"


# static fields
.field private static final MAX_ROUNDS:I = 0x6

.field private static final ROUND_INTERVAL_MS:J = 0x3e8L

.field private static final TAG:Ljava/lang/String; = "HangupController"

.field private static volatile sGeneration:I

.field private static volatile sLastFireElapsed:J


# direct methods
.method static bridge synthetic -$$Nest$sfgetsGeneration()I
    .locals 1

    sget v0, Lcom/calltimer/app/HangupController;->sGeneration:I

    return v0
.end method

.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static cancel()V
    .locals 2

    .line 31
    sget v0, Lcom/calltimer/app/HangupController;->sGeneration:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lcom/calltimer/app/HangupController;->sGeneration:I

    .line 32
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "hangup generation cancelled -> "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget v1, Lcom/calltimer/app/HangupController;->sGeneration:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "HangupController"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 33
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "hangup flow cancelled -> gen "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget v1, Lcom/calltimer/app/HangupController;->sGeneration:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    invoke-static {}, Lcom/calltimer/app/HangupReporter;->report()V

    return-void
.end method

.method public static run(Landroid/content/Context;Ljava/lang/Runnable;)V
    .locals 11

    .line 38
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    .line 39
    new-instance p0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 40
    sget v1, Lcom/calltimer/app/HangupController;->sGeneration:I

    .line 43
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    .line 44
    sget-wide v5, Lcom/calltimer/app/HangupController;->sLastFireElapsed:J

    sub-long v5, v3, v5

    const-wide/16 v7, 0x5dc

    cmp-long v0, v5, v7

    if-gez v0, :cond_1

    if-eqz p1, :cond_0

    .line 45
    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :cond_0
    return-void

    .line 48
    :cond_1
    sput-wide v3, Lcom/calltimer/app/HangupController;->sLastFireElapsed:J

    .line 49
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "hangup flow start, generation="

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v3, "HangupController"

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 52
    const-string v0, "power"

    invoke-virtual {v2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    const-string v3, "calltimer:hangup"

    const/4 v4, 0x1

    .line 53
    invoke-virtual {v0, v4, v3}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v6

    const-wide/16 v7, 0x3a98

    .line 55
    :try_start_0
    invoke-virtual {v6, v7, v8}, Landroid/os/PowerManager$WakeLock;->acquire(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v8, 0x0

    .line 58
    filled-new-array {v8}, [I

    move-result-object v3

    .line 59
    new-array v9, v4, [Ljava/lang/Runnable;

    .line 60
    new-instance v10, Lcom/calltimer/app/HangupController$1;

    move-object v0, v10

    move-object v4, p0

    move-object v5, v9

    move-object v7, p1

    invoke-direct/range {v0 .. v7}, Lcom/calltimer/app/HangupController$1;-><init>(ILandroid/content/Context;[ILandroid/os/Handler;[Ljava/lang/Runnable;Landroid/os/PowerManager$WakeLock;Ljava/lang/Runnable;)V

    aput-object v10, v9, v8

    .line 142
    aget-object p1, v9, v8

    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
