.class Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;
.super Ljava/lang/Object;
.source "HangupAccessibilityService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/HangupAccessibilityService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "AttemptRunnable"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/HangupAccessibilityService;

.field private tries:I


# direct methods
.method private constructor <init>(Lcom/calltimer/app/HangupAccessibilityService;)V
    .locals 0

    .line 462
    iput-object p1, p0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;->this$0:Lcom/calltimer/app/HangupAccessibilityService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    .line 463
    iput p1, p0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;->tries:I

    return-void
.end method

.method synthetic constructor <init>(Lcom/calltimer/app/HangupAccessibilityService;Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;-><init>(Lcom/calltimer/app/HangupAccessibilityService;)V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 467
    const-string v0, "A11yHangup"

    iget v1, p0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;->tries:I

    const/4 v2, 0x6

    if-lt v1, v2, :cond_0

    return-void

    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 468
    iput v1, p0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;->tries:I

    .line 471
    :try_start_0
    iget-object v1, p0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;->this$0:Lcom/calltimer/app/HangupAccessibilityService;

    invoke-static {v1}, Lcom/calltimer/app/HangupAccessibilityService;->-$$Nest$mattemptHangup(Lcom/calltimer/app/HangupAccessibilityService;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-static {}, Lcom/calltimer/app/HangupReporter;->report()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    goto :goto_0

    :catchall_0
    move-exception v1

    .line 473
    const-string v2, "attempt error"

    invoke-static {v0, v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v1, 0x0

    .line 476
    :goto_0
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "hangup attempt "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v4, p0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;->tries:I

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " result="

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 477
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, p0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;->tries:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/HangupAccessibilityService;->log(Ljava/lang/String;)V

    if-nez v1, :cond_2

    .line 478
    iget-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService$AttemptRunnable;->this$0:Lcom/calltimer/app/HangupAccessibilityService;

    invoke-static {v0}, Lcom/calltimer/app/HangupAccessibilityService;->-$$Nest$fgetmMain(Lcom/calltimer/app/HangupAccessibilityService;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x320

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_2
    return-void
.end method
