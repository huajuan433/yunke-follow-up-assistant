.class public Lcom/calltimer/app/YkOverlay;
.super Ljava/lang/Object;
.source "YkOverlay.java"


# static fields
.field private static sSecView:Landroid/widget/TextView;

.field private static sStatusView:Landroid/widget/TextView;

.field private static sSwView:Landroid/widget/Button;

.field private static sView:Landroid/view/View;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static build(Landroid/content/Context;)Landroid/view/View;
    .locals 15

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const v5, -0xfe5ddca    # -1.908082E29f

    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v5, 0x1

    const v6, 0x33ffffff

    invoke-virtual {v4, v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    const/high16 v6, 0x41c00000    # 24.0f

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v4, 0x14

    invoke-virtual {v2, v4, v4, v4, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v4, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual {v5, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v7, "\u26a1 \u6302\u65ad\u8054\u52a8"

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v7, 0x41900000    # 18.0f

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    const v7, -0xe0a07

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v8, "v53"

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v8, 0x41200000    # 10.0f

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextSize(F)V

    const v8, -0x822c04

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v8, 0x8

    const/4 v9, 0x0

    invoke-virtual {v7, v8, v9, v8, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    new-instance v8, Landroid/widget/Button;

    invoke-direct {v8, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v10, "\u2715"

    invoke-virtual {v8, v10}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/high16 v10, 0x41400000    # 12.0f

    invoke-virtual {v8, v10}, Landroid/widget/Button;->setTextSize(F)V

    const v10, -0x6b5c48

    invoke-virtual {v8, v10}, Landroid/widget/Button;->setTextColor(I)V

    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v10}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const v11, 0x1affffff

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v11, 0x41200000    # 10.0f

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v8, v10}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v10, 0xc

    invoke-virtual {v8, v10, v10, v10, v10}, Landroid/widget/Button;->setPadding(IIII)V

    const/16 v10, 0x28

    invoke-virtual {v8, v10, v10}, Landroid/widget/Button;->setMinimumWidth(II)V

    invoke-virtual {v8, v10, v10}, Landroid/widget/Button;->setMinimumHeight(II)V

    new-instance v10, Lcom/calltimer/app/YkOverlay$1;

    invoke-direct {v10}, Lcom/calltimer/app/YkOverlay$1;-><init>()V

    invoke-virtual {v8, v10}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v5, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v6, "\u7a7a\u95f2"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v6, 0x41400000    # 12.0f

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const v6, -0x6b5c48

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v6, 0x8

    const/4 v7, 0x0

    invoke-virtual {v5, v7, v6, v7, v6}, Landroid/widget/TextView;->setPadding(IIII)V

    const/16 v6, 0x11

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setGravity(I)V

    sput-object v5, Lcom/calltimer/app/YkOverlay;->sStatusView:Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/view/View;

    invoke-direct {v5, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, 0x1

    invoke-direct {v6, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0x10

    const/4 v8, 0x0

    invoke-virtual {v6, v8, v7, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v5, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v6, 0x33ffffff

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v6, "\u23f1 \u81ea\u52a8\u6302\u65ad\u5012\u8ba1\u65f6"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v6, 0x41400000    # 12.0f

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const v6, -0x746753

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v6, 0x8

    const/4 v7, 0x0

    invoke-virtual {v5, v7, v6, v7, v6}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v6, 0x11

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, -0x2

    invoke-direct {v6, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const v7, 0x1affffff

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v7, 0x41200000    # 10.0f

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance v7, Landroid/widget/Button;

    invoke-direct {v7, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v8, "\u2212"

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/high16 v8, 0x42000000    # 32.0f

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setTextSize(F)V

    invoke-virtual {v7, v6}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const v8, -0x822c04

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setTextColor(I)V

    const/16 v8, 0x18

    invoke-virtual {v7, v8, v8, v8, v8}, Landroid/widget/Button;->setPadding(IIII)V

    const/16 v8, 0x40

    invoke-virtual {v7, v8, v8}, Landroid/widget/Button;->setMinimumWidth(II)V

    invoke-virtual {v7, v8, v8}, Landroid/widget/Button;->setMinimumHeight(II)V

    new-instance v8, Lcom/calltimer/app/YkOverlay$2;

    invoke-direct {v8}, Lcom/calltimer/app/YkOverlay$2;-><init>()V

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/16 v9, 0x20

    const/4 v10, 0x0

    invoke-virtual {v8, v9, v10, v9, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    const/high16 v9, 0x42200000    # 40.0f

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextSize(F)V

    const v9, -0x440dc

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v9, 0x11

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x0

    const/4 v11, -0x2

    invoke-direct {v9, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v10, 0x3f800000    # 1.0f

    iput v10, v9, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    sput-object v8, Lcom/calltimer/app/YkOverlay;->sSecView:Landroid/widget/TextView;

    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const v9, 0x1affffff

    invoke-virtual {v11, v9}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v9, 0x41200000    # 10.0f

    invoke-virtual {v11, v9}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance v9, Landroid/widget/Button;

    invoke-direct {v9, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v10, "+"

    invoke-virtual {v9, v10}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/high16 v10, 0x42000000    # 32.0f

    invoke-virtual {v9, v10}, Landroid/widget/Button;->setTextSize(F)V

    invoke-virtual {v9, v11}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const v10, -0x822c04

    invoke-virtual {v9, v10}, Landroid/widget/Button;->setTextColor(I)V

    const/16 v10, 0x18

    invoke-virtual {v9, v10, v10, v10, v10}, Landroid/widget/Button;->setPadding(IIII)V

    const/16 v10, 0x40

    invoke-virtual {v9, v10, v10}, Landroid/widget/Button;->setMinimumWidth(II)V

    invoke-virtual {v9, v10, v10}, Landroid/widget/Button;->setMinimumHeight(II)V

    new-instance v10, Lcom/calltimer/app/YkOverlay$3;

    invoke-direct {v10}, Lcom/calltimer/app/YkOverlay$3;-><init>()V

    invoke-virtual {v9, v10}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v5, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v5, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/Button;

    invoke-direct {v5, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const/high16 v6, 0x41500000    # 13.0f

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setTextSize(F)V

    const v6, -0xe0a07

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setTextColor(I)V

    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const v7, -0xdd3aa2

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v7, 0x41200000    # 10.0f

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v6, 0xe

    invoke-virtual {v5, v6, v6, v6, v6}, Landroid/widget/Button;->setPadding(IIII)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, -0x2

    invoke-direct {v6, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0xc

    const/4 v8, 0x0

    invoke-virtual {v6, v8, v7, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v6, Lcom/calltimer/app/YkOverlay$4;

    invoke-direct {v6}, Lcom/calltimer/app/YkOverlay$4;-><init>()V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    sput-object v5, Lcom/calltimer/app/YkOverlay;->sSwView:Landroid/widget/Button;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v6, "\u672a\u63a5\u901a\u5230\u70b9\u81ea\u52a8\u6302\u65ad \u00b7 \u63a5\u901a\u540e\u540c\u6837\u5230\u70b9\u81ea\u52a8\u6302\u65ad"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v6, 0x41200000    # 10.0f

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const v6, -0xa49780

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v6, 0x8

    const/4 v7, 0x0

    invoke-virtual {v5, v7, v6, v7, v6}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/Button;

    invoke-direct {v5, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const-string v6, "\u6253\u5f00\u4e3b\u5e94\u7528"

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const v6, -0x822c04

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setTextColor(I)V

    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const v7, 0x1a38bdf8

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v7, 0x41200000    # 10.0f

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/4 v7, 0x1

    const v8, 0x3338bdf8

    invoke-virtual {v6, v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v6, 0xa

    invoke-virtual {v5, v6, v6, v6, v6}, Landroid/widget/Button;->setPadding(IIII)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, -0x2

    invoke-direct {v6, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0x8

    const/4 v8, 0x0

    invoke-virtual {v6, v8, v7, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v6, Lcom/calltimer/app/YkOverlay$5;

    invoke-direct {v6, p0}, Lcom/calltimer/app/YkOverlay$5;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v5, "window"

    invoke-virtual {p0, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/view/WindowManager;

    new-instance v6, Landroid/view/WindowManager$LayoutParams;

    const/4 v7, -0x2

    const/4 v8, -0x2

    const/16 v9, 0x7f0

    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isOverlayOnTop(Landroid/content/Context;)Z

    move-result v13

    if-eqz v13, :cond_0

    const/16 v10, 0x28

    goto :goto_0

    :cond_0
    const/16 v10, 0x38

    :goto_0
    const/4 v11, -0x3

    invoke-direct/range {v6 .. v11}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    const/16 v7, 0x64

    iput v7, v6, Landroid/view/WindowManager$LayoutParams;->x:I

    const/16 v7, 0xc8

    iput v7, v6, Landroid/view/WindowManager$LayoutParams;->y:I

    const v12, 0x800035

    iput v12, v6, Landroid/view/WindowManager$LayoutParams;->gravity:I

    invoke-interface {v5, v2, v6}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v2
.end method

.method public static hide()V
    .locals 3

    :try_start_0
    sget-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    if-eqz v0, :cond_0

    sget-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "window"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager;

    if-eqz v1, :cond_0

    sget-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    invoke-interface {v1, v0}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    :goto_0
    const/4 v0, 0x0

    sput-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    sput-object v0, Lcom/calltimer/app/YkOverlay;->sSecView:Landroid/widget/TextView;

    sput-object v0, Lcom/calltimer/app/YkOverlay;->sSwView:Landroid/widget/Button;

    sput-object v0, Lcom/calltimer/app/YkOverlay;->sStatusView:Landroid/widget/TextView;

    return-void

    :catchall_0
    move-exception v1

    goto :goto_0
.end method

.method public static refresh()V
    .locals 10

    :try_start_0
    sget-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->ykIsAlive()Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Prefs;->isEnabled(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v0, "\u25cf \u81ea\u52a8\u6302\u65ad\u5df2\u542f\u7528"

    goto :goto_0

    :cond_1
    const-string v0, "\u25cb \u81ea\u52a8\u6302\u65ad\u5df2\u505c\u7528"

    goto :goto_0

    :cond_2
    const-string v0, "\u25cb \u65e0\u969c\u788d\u672a\u5f00\u542f"

    :goto_0
    sget-object v1, Lcom/calltimer/app/YkOverlay;->sSwView:Landroid/widget/Button;

    if-eqz v1, :cond_3

    invoke-virtual {v1, v0}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    :cond_3
    sget-object v1, Lcom/calltimer/app/YkOverlay;->sSecView:Landroid/widget/TextView;

    if-eqz v1, :cond_4

    sget-object v1, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lcom/calltimer/app/Prefs;->getSeconds(Landroid/content/Context;)I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "s"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Lcom/calltimer/app/YkOverlay;->sSecView:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_4
    sget-object v4, Lcom/calltimer/app/YkOverlay;->sStatusView:Landroid/widget/TextView;

    if-eqz v4, :cond_7

    invoke-static {}, Lcom/calltimer/app/CallTimerService;->getPhase()Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v5

    sget-object v6, Lcom/calltimer/app/CallTimerService$Phase;->IDLE:Lcom/calltimer/app/CallTimerService$Phase;

    if-ne v5, v6, :cond_5

    const-string v7, "\u7a7a\u95f2"

    const v8, -0x6b5c48

    goto :goto_1

    :cond_5
    sget-object v6, Lcom/calltimer/app/CallTimerService$Phase;->WAITING:Lcom/calltimer/app/CallTimerService$Phase;

    if-ne v5, v6, :cond_6

    const-string v7, "\u7b49\u5f85\u63a5\u901a\u2026\uff08\u672a\u63a5\u901a\uff09"

    const v8, -0x440dc

    goto :goto_1

    :cond_6
    const-string v7, "\u2713 \u5df2\u63a5\u901a"

    const v8, -0xdd3aa2

    :goto_1
    sget-object v9, Lcom/calltimer/app/YkOverlay;->sStatusView:Landroid/widget/TextView;

    invoke-virtual {v9, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    sget-object v9, Lcom/calltimer/app/YkOverlay;->sStatusView:Landroid/widget/TextView;

    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_7
    invoke-static {}, Lcom/calltimer/app/CallTimerService;->getPhase()Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v5

    sget-object v6, Lcom/calltimer/app/CallTimerService$Phase;->IDLE:Lcom/calltimer/app/CallTimerService$Phase;

    if-ne v5, v6, :cond_8

    sget-object v5, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    if-eqz v5, :cond_8

    invoke-virtual {v5}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Lcom/calltimer/app/Prefs;->isOverlayOnTop(Landroid/content/Context;)Z

    move-result v5

    if-nez v5, :cond_8

    invoke-static {}, Lcom/calltimer/app/YkOverlay;->hide()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_8
    return-void

    :catchall_0
    move-exception v0

    return-void
.end method

.method public static show(Landroid/content/Context;)V
    .locals 2

    :try_start_0
    invoke-static {p0}, Lcom/calltimer/app/Prefs;->isOverlayEnabled(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Lcom/calltimer/app/YkOverlay;->hide()V

    return-void

    :cond_0
    sget-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    if-eqz v0, :cond_1

    sget-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-nez v0, :cond_2

    :cond_1
    invoke-static {p0}, Lcom/calltimer/app/YkOverlay;->build(Landroid/content/Context;)Landroid/view/View;

    move-result-object v0

    sput-object v0, Lcom/calltimer/app/YkOverlay;->sView:Landroid/view/View;

    :cond_2
    invoke-static {}, Lcom/calltimer/app/YkOverlay;->refresh()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception v0

    return-void
.end method
