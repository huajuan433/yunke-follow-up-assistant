.class public final Lcom/calltimer/app/CallTimerService$HeartbeatTask;
.super Ljava/lang/Object;
.source "CallTimerService.java"

# interfaces
.implements Ljava/lang/Runnable;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    sget-object v0, Lcom/calltimer/app/CallTimerService;->sHBHandler:Landroid/os/Handler;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->ykIsAlive()Z

    move-result v1

    invoke-static {v1}, Lcom/calltimer/app/HangupReporter;->ykHeartbeat(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    const-string v1, "hb error"

    invoke-static {v1}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    :goto_0
    const-wide/16 v2, 0x4e20

    invoke-virtual {v0, p0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void
.end method
