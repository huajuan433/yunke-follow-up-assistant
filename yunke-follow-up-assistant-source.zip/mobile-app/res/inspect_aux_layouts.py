from pathlib import Path
import xml.etree.ElementTree as ET
base=Path(r'D:\Users\Lenovo\C_drive_links\migrated_from_c\Documents\Codex\2026-11-05\wei-s\mobile-app-opt\apk-v81-decoded\res\layout')
A='{http://schemas.android.com/apk/res/android}'
for filename in ('activity_recommend.xml','activity_check.xml'):
 root=ET.parse(base/filename).getroot(); print('\n'+filename)
 for e in root.iter():
  tag=e.tag.rsplit('}',1)[-1]
  vals=[]
  for key in ('id','text','background','textColor','textSize','onClick','visibility'):
   v=e.attrib.get(A+key)
   if v: vals.append(key+'='+v)
  if vals: print(tag+' '+' | '.join(vals))
