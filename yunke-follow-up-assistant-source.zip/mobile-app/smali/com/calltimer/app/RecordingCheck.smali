.class public final Lcom/calltimer/app/RecordingCheck;
.super Ljava/lang/Object;
.source "RecordingCheck.java"

# interfaces
.implements Ljava/lang/Runnable;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    :try_start_0
    invoke-static {}, Lcom/calltimer/app/CallTimerService;->ykScanRecording()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception v0

    const-string p0, "rec check error"

    invoke-static {p0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    return-void
.end method
