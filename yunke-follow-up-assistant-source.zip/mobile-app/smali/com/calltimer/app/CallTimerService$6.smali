.class Lcom/calltimer/app/CallTimerService$6;
.super Landroid/telephony/PhoneStateListener;
.source "CallTimerService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/calltimer/app/CallTimerService;->registerCallState()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/CallTimerService;


# direct methods
.method constructor <init>(Lcom/calltimer/app/CallTimerService;)V
    .locals 0

    .line 378
    iput-object p1, p0, Lcom/calltimer/app/CallTimerService$6;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-direct {p0}, Landroid/telephony/PhoneStateListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onCallStateChanged(ILjava/lang/String;)V
    .locals 1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    if-eqz p2, :cond_0

    :try_start_0
    invoke-static {p2}, Lcom/calltimer/app/HangupReporter;->ykIncomingReport(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    .line 381
    :catchall_0
    :cond_0
    :goto_0
    iget-object p2, p0, Lcom/calltimer/app/CallTimerService$6;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {p2, p1}, Lcom/calltimer/app/CallTimerService;->-$$Nest$mhandleCallState(Lcom/calltimer/app/CallTimerService;I)V

    return-void
.end method
