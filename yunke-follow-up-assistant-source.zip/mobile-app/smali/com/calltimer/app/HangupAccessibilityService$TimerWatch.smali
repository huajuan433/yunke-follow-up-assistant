.class Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;
.super Ljava/lang/Object;
.source "HangupAccessibilityService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/HangupAccessibilityService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "TimerWatch"
.end annotation


# instance fields
.field private confirmed:Z

.field private evidence:Ljava/lang/String;

.field private final points:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "[D>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .locals 1

    .line 363
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 364
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->points:Ljava/util/List;

    const/4 v0, 0x0

    .line 365
    iput-boolean v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->confirmed:Z

    .line 366
    const-string v0, ""

    iput-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->evidence:Ljava/lang/String;

    return-void
.end method

.method static synthetic lambda$update$0(J[D)Z
    .locals 3

    long-to-double p0, p0

    const/4 v0, 0x1

    .line 388
    aget-wide v1, p2, v0

    sub-double/2addr p0, v1

    const-wide v1, 0x40b7700000000000L    # 6000.0

    cmpl-double p0, p0, v1

    if-lez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private parseMmSs(Ljava/lang/String;)I
    .locals 3

    const/4 v0, -0x1

    .line 410
    :try_start_0
    const-string v1, ":"

    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 411
    array-length v1, p1

    const/4 v2, 0x2

    if-eq v1, v2, :cond_0

    return v0

    :cond_0
    const/4 v1, 0x0

    .line 412
    aget-object v1, p1, v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x1

    .line 413
    aget-object p1, p1, v2

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-ltz p1, :cond_2

    const/16 v2, 0x3b

    if-gt p1, v2, :cond_2

    if-gez v1, :cond_1

    goto :goto_0

    :cond_1
    mul-int/lit8 v1, v1, 0x3c

    add-int/2addr v1, p1

    return v1

    :catchall_0
    :cond_2
    :goto_0
    return v0
.end method


# virtual methods
.method declared-synchronized evidence()Ljava/lang/String;
    .locals 1

    monitor-enter p0

    .line 379
    :try_start_0
    iget-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->evidence:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method declared-synchronized isConfirmed()Z
    .locals 1

    monitor-enter p0

    .line 375
    :try_start_0
    iget-boolean v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->confirmed:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return v0

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method declared-synchronized reset()V
    .locals 1

    monitor-enter p0

    .line 369
    :try_start_0
    iget-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->points:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v0, 0x0

    .line 370
    iput-boolean v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->confirmed:Z

    .line 371
    const-string v0, ""

    iput-object v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->evidence:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 372
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method declared-synchronized update(Ljava/util/Collection;J)Z
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Ljava/lang/String;",
            ">;J)Z"
        }
    .end annotation

    monitor-enter p0

    .line 383
    :try_start_0
    iget-boolean v0, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->confirmed:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    monitor-exit p0

    return v1

    .line 384
    :cond_0
    :try_start_1
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 385
    invoke-direct {p0, v0}, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->parseMmSs(Ljava/lang/String;)I

    move-result v0

    if-ltz v0, :cond_1

    const/16 v3, 0xe10

    if-le v0, v3, :cond_2

    goto :goto_0

    .line 388
    :cond_2
    iget-object v3, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->points:Ljava/util/List;

    new-instance v4, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch$$ExternalSyntheticLambda0;

    invoke-direct {v4, p2, p3}, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch$$ExternalSyntheticLambda0;-><init>(J)V

    invoke-interface {v3, v4}, Ljava/util/List;->removeIf(Ljava/util/function/Predicate;)Z

    .line 389
    iget-object v3, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->points:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [D

    .line 390
    aget-wide v5, v4, v2

    double-to-int v5, v5

    sub-int v5, v0, v5

    .line 391
    aget-wide v6, v4, v1

    double-to-long v6, v6

    sub-long v6, p2, v6

    if-lt v5, v1, :cond_3

    const/4 v8, 0x3

    if-gt v5, v8, :cond_3

    const-wide/16 v8, 0x12c

    cmp-long v5, v6, v8

    if-ltz v5, :cond_3

    const-wide/16 v8, 0x1388

    cmp-long v5, v6, v8

    if-gtz v5, :cond_3

    .line 393
    iput-boolean v1, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->confirmed:Z

    .line 394
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    aget-wide p2, v4, v2

    double-to-int p2, p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, "s->"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, "s"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->evidence:Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 395
    monitor-exit p0

    return v1

    .line 400
    :cond_4
    :try_start_2
    iget-object v3, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->points:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [D

    .line 401
    aget-wide v5, v4, v2

    double-to-int v5, v5

    if-ne v5, v0, :cond_5

    long-to-double v2, p2

    aput-wide v2, v4, v1

    goto/16 :goto_0

    .line 403
    :cond_6
    iget-object v3, p0, Lcom/calltimer/app/HangupAccessibilityService$TimerWatch;->points:Ljava/util/List;

    int-to-double v4, v0

    long-to-double v6, p2

    const/4 v0, 0x2

    new-array v0, v0, [D

    aput-wide v4, v0, v2

    aput-wide v6, v0, v1

    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto/16 :goto_0

    .line 405
    :cond_7
    monitor-exit p0

    return v2

    :catchall_0
    move-exception p1

    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p1
.end method
