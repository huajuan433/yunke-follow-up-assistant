.class public Lcom/calltimer/app/App;
.super Landroid/app/Application;
.source "App.java"


# static fields
.field public static final CRASH_FILE:Ljava/lang/String; = "crash.txt"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 16
    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method

.method public static readAndClearCrash(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const/4 v0, 0x0

    .line 58
    :try_start_0
    new-instance v1, Ljava/io/File;

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    const-string v2, "crash.txt"

    invoke-direct {v1, p0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 59
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p0

    if-eqz p0, :cond_2

    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long p0, v2, v4

    if-nez p0, :cond_0

    goto :goto_0

    .line 60
    :cond_0
    invoke-virtual {v1}, Ljava/io/File;->length()J

    move-result-wide v2

    long-to-int p0, v2

    new-array p0, p0, [B

    .line 61
    new-instance v2, Ljava/io/FileInputStream;

    invoke-direct {v2, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 62
    invoke-virtual {v2, p0}, Ljava/io/FileInputStream;->read([B)I

    move-result v3

    .line 63
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 64
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    if-gtz v3, :cond_1

    return-object v0

    .line 66
    :cond_1
    new-instance v1, Ljava/lang/String;

    const-string v2, "UTF-8"

    const/4 v4, 0x0

    invoke-direct {v1, p0, v4, v3, v2}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v1

    :catchall_0
    :cond_2
    :goto_0
    return-object v0
.end method


# virtual methods
.method public onCreate()V
    .locals 2

    .line 22
    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    .line 23
    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v0

    .line 24
    new-instance v1, Lcom/calltimer/app/App$1;

    invoke-direct {v1, p0, v0}, Lcom/calltimer/app/App$1;-><init>(Lcom/calltimer/app/App;Ljava/lang/Thread$UncaughtExceptionHandler;)V

    invoke-static {v1}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    return-void
.end method
