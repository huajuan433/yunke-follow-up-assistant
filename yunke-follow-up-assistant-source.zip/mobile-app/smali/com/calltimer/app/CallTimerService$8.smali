.class synthetic Lcom/calltimer/app/CallTimerService$8;
.super Ljava/lang/Object;
.source "CallTimerService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/CallTimerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic $SwitchMap$com$calltimer$app$CallTimerService$Phase:[I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 324
    invoke-static {}, Lcom/calltimer/app/CallTimerService$Phase;->values()[Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    sput-object v0, Lcom/calltimer/app/CallTimerService$8;->$SwitchMap$com$calltimer$app$CallTimerService$Phase:[I

    :try_start_0
    sget-object v1, Lcom/calltimer/app/CallTimerService$Phase;->WAITING:Lcom/calltimer/app/CallTimerService$Phase;

    invoke-virtual {v1}, Lcom/calltimer/app/CallTimerService$Phase;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    sget-object v0, Lcom/calltimer/app/CallTimerService$8;->$SwitchMap$com$calltimer$app$CallTimerService$Phase:[I

    sget-object v1, Lcom/calltimer/app/CallTimerService$Phase;->CONNECTED:Lcom/calltimer/app/CallTimerService$Phase;

    invoke-virtual {v1}, Lcom/calltimer/app/CallTimerService$Phase;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    sget-object v0, Lcom/calltimer/app/CallTimerService$8;->$SwitchMap$com$calltimer$app$CallTimerService$Phase:[I

    sget-object v1, Lcom/calltimer/app/CallTimerService$Phase;->IDLE:Lcom/calltimer/app/CallTimerService$Phase;

    invoke-virtual {v1}, Lcom/calltimer/app/CallTimerService$Phase;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    return-void
.end method
