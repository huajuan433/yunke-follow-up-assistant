.class public final Lcom/calltimer/app/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static accessibility_service_desc:I = 0x7f060000

.field public static accessibility_service_label:I = 0x7f060001

.field public static app_name:I = 0x7f060002

.field public static autostart_dialog_body:I = 0x7f060003

.field public static autostart_dialog_title:I = 0x7f060004

.field public static btn_go:I = 0x7f060005

.field public static btn_grant:I = 0x7f060006

.field public static channel_desc:I = 0x7f060007

.field public static channel_name:I = 0x7f060008

.field public static countdown_hint:I = 0x7f060009

.field public static countdown_label:I = 0x7f06000a

.field public static dialog_ok:I = 0x7f06000b

.field public static disabled_toast:I = 0x7f06000c

.field public static enable_label:I = 0x7f06000d

.field public static enabled_toast:I = 0x7f06000e

.field public static guide_body:I = 0x7f06000f

.field public static guide_title:I = 0x7f060010

.field public static need_a11y_perm:I = 0x7f060011

.field public static need_phone_perm:I = 0x7f060012

.field public static noti_connected:I = 0x7f060013

.field public static noti_idle:I = 0x7f060014

.field public static noti_need_a11y:I = 0x7f060015

.field public static noti_waiting_countdown:I = 0x7f060016

.field public static noti_waiting_silent:I = 0x7f060017

.field public static perm_a11y:I = 0x7f060018

.field public static perm_autostart:I = 0x7f060019

.field public static perm_battery:I = 0x7f06001a

.field public static perm_notification:I = 0x7f06001b

.field public static perm_phone:I = 0x7f06001c

.field public static perm_title:I = 0x7f06001d

.field public static quick_label:I = 0x7f06001e

.field public static seconds_hint:I = 0x7f06001f

.field public static seconds_saved:I = 0x7f060020

.field public static state_needed:I = 0x7f060021

.field public static state_off:I = 0x7f060022

.field public static state_on:I = 0x7f060023

.field public static status_running:I = 0x7f060024

.field public static status_stopped:I = 0x7f060025

.field public static title_seconds:I = 0x7f060026


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
