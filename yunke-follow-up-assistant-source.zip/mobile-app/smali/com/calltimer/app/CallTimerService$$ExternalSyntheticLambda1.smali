.class public final synthetic Lcom/calltimer/app/CallTimerService$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;


# instance fields
.field public final synthetic f$0:Lcom/calltimer/app/CallTimerService;


# direct methods
.method public synthetic constructor <init>(Lcom/calltimer/app/CallTimerService;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/calltimer/app/CallTimerService$$ExternalSyntheticLambda1;->f$0:Lcom/calltimer/app/CallTimerService;

    return-void
.end method


# virtual methods
.method public final onState(I)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$$ExternalSyntheticLambda1;->f$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0, p1}, Lcom/calltimer/app/CallTimerService;->$r8$lambda$yMeWpaSIZytKpzkOCwWxfpC_kTc(Lcom/calltimer/app/CallTimerService;I)V

    return-void
.end method
