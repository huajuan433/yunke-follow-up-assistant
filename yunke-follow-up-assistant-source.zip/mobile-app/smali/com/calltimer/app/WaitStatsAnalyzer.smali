.class public final Lcom/calltimer/app/WaitStatsAnalyzer;
.super Ljava/lang/Object;
.source "WaitStatsAnalyzer.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/calltimer/app/WaitStatsAnalyzer$Result;,
        Lcom/calltimer/app/WaitStatsAnalyzer$Row;
    }
.end annotation


# static fields
.field public static final FALLBACK_SECONDS:I = 0x1e

.field private static final MAX_WAIT:I = 0x3c


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static addRowIfDistinct(Lcom/calltimer/app/WaitStatsAnalyzer$Result;Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V
    .locals 5

    .line 106
    iget-object v0, p0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->rows:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    .line 107
    iget-wide v1, v1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->seconds:J

    iget-wide v3, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->seconds:J

    cmp-long v1, v1, v3

    if-nez v1, :cond_0

    return-void

    .line 109
    :cond_1
    iget-object p0, p0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->rows:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public static analyze(Landroid/content/Context;)Lcom/calltimer/app/WaitStatsAnalyzer$Result;
    .locals 12

    .line 60
    new-instance v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;

    invoke-direct {v0}, Lcom/calltimer/app/WaitStatsAnalyzer$Result;-><init>()V

    .line 61
    invoke-static {p0}, Lcom/calltimer/app/WaitStatsStore;->read(Landroid/content/Context;)Ljava/util/List;

    move-result-object v1

    .line 62
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    iput v2, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->total:I

    .line 64
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 65
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [I

    .line 66
    aget v4, v3, v4

    if-ne v4, v5, :cond_0

    aget v3, v3, v5

    int-to-long v3, v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 68
    :cond_1
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v1

    iput v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->connectedCount:I

    .line 69
    iget v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->total:I

    iget v3, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->connectedCount:I

    sub-int/2addr v1, v3

    iput v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->missedCount:I

    .line 70
    iget v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->total:I

    if-lez v1, :cond_2

    iget v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->connectedCount:I

    int-to-double v6, v1

    iget v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->total:I

    int-to-double v8, v1

    div-double/2addr v6, v8

    goto :goto_1

    :cond_2
    const-wide/16 v6, 0x0

    :goto_1
    iput-wide v6, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->answerRate:D

    .line 72
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v1

    const/16 v3, 0xa

    const-wide/16 v6, 0x3c

    if-lt v1, v3, :cond_5

    .line 73
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v1

    new-array v3, v1, [J

    move v8, v4

    :goto_2
    if-ge v8, v1, :cond_3

    .line 74
    invoke-interface {v2, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Long;

    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    aput-wide v9, v3, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_2

    .line 75
    :cond_3
    invoke-static {v3}, Ljava/util/Arrays;->sort([J)V

    const-wide/high16 v8, 0x3fe0000000000000L    # 0.5

    .line 76
    invoke-static {v3, v8, v9}, Lcom/calltimer/app/WaitStatsAnalyzer;->quantile([JD)J

    move-result-wide v8

    iput-wide v8, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->medianWait:J

    const-wide v8, 0x3fe999999999999aL    # 0.8

    .line 77
    invoke-static {v3, v8, v9}, Lcom/calltimer/app/WaitStatsAnalyzer;->quantile([JD)J

    move-result-wide v8

    iput-wide v8, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->p80Wait:J

    const-wide v8, 0x3feccccccccccccdL    # 0.9

    .line 78
    invoke-static {v3, v8, v9}, Lcom/calltimer/app/WaitStatsAnalyzer;->quantile([JD)J

    move-result-wide v8

    iput-wide v8, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->p90Wait:J

    const-wide v8, 0x3fee666666666666L    # 0.95

    .line 79
    invoke-static {v3, v8, v9}, Lcom/calltimer/app/WaitStatsAnalyzer;->quantile([JD)J

    move-result-wide v8

    iput-wide v8, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->p95Wait:J

    const-wide/16 v8, 0x0

    :goto_3
    if-ge v4, v1, :cond_4

    .line 81
    aget-wide v10, v3, v4

    add-long/2addr v8, v10

    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    :cond_4
    long-to-double v2, v8

    int-to-double v8, v1

    div-double/2addr v2, v8

    .line 82
    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v1

    iput-wide v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->meanWait:J

    const-wide/16 v1, 0x5

    .line 83
    iget-wide v3, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->p90Wait:J

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    invoke-static {v6, v7, v1, v2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v1

    iput-wide v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    .line 84
    iput-boolean v5, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->enoughSamples:Z

    goto :goto_4

    :cond_5
    const-wide/16 v1, 0x1e

    .line 86
    iput-wide v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    .line 87
    iput-boolean v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->enoughSamples:Z

    .line 90
    :goto_4
    iget-object v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->rows:Ljava/util/List;

    new-instance v2, Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    iget-wide v3, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    .line 91
    iget-boolean v5, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->enoughSamples:Z

    if-eqz v5, :cond_6

    .line 92
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v8, "90% \u4f1a\u63a5\u7684\u7535\u8bdd\u5728 "

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v8, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    invoke-virtual {v5, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " \u79d2\u5185\u63a5\u8d77"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_5

    .line 93
    :cond_6
    const-string v5, "\u6837\u672c\u4e0d\u8db3\uff0c\u5148\u7528\u7ecf\u9a8c\u503c 30 \u79d2\uff08\u7ea6 5 \u58f0\u56de\u94c3\uff09"

    :goto_5
    const-string v8, "\u2605 \u63a8\u8350\u7b49\u5f85"

    invoke-direct {v2, v8, v3, v4, v5}, Lcom/calltimer/app/WaitStatsAnalyzer$Row;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    .line 90
    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 94
    iget-boolean v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->enoughSamples:Z

    if-eqz v1, :cond_7

    .line 95
    new-instance v1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    iget-wide v2, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->p80Wait:J

    const-string v4, "80% \u7684\u63a5\u901a\u7535\u8bdd\u5728\u6b64\u65f6\u95f4\u5185\u63a5\u8d77"

    const-string v5, "P80 \u7b49\u5f85"

    invoke-direct {v1, v5, v2, v3, v4}, Lcom/calltimer/app/WaitStatsAnalyzer$Row;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    invoke-static {v0, v1}, Lcom/calltimer/app/WaitStatsAnalyzer;->addRowIfDistinct(Lcom/calltimer/app/WaitStatsAnalyzer$Result;Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V

    .line 96
    new-instance v1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    iget-wide v2, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->p95Wait:J

    invoke-static {v6, v7, v2, v3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    const-string v4, "\u66f4\u4fdd\u5b88\uff0c\u5c11\u6f0f\u63a5"

    const-string v5, "P95 \u7b49\u5f85"

    invoke-direct {v1, v5, v2, v3, v4}, Lcom/calltimer/app/WaitStatsAnalyzer$Row;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    invoke-static {v0, v1}, Lcom/calltimer/app/WaitStatsAnalyzer;->addRowIfDistinct(Lcom/calltimer/app/WaitStatsAnalyzer$Result;Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V

    .line 98
    :cond_7
    new-instance v1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    const-wide/16 v2, 0x14

    const-string v4, "\u7ea6 3 \u58f0\u56de\u94c3\uff0c\u66f4\u5feb\u6302\u65ad"

    const-string v5, "\u7ecf\u9a8c 20 \u79d2"

    invoke-direct {v1, v5, v2, v3, v4}, Lcom/calltimer/app/WaitStatsAnalyzer$Row;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    invoke-static {v0, v1}, Lcom/calltimer/app/WaitStatsAnalyzer;->addRowIfDistinct(Lcom/calltimer/app/WaitStatsAnalyzer$Result;Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V

    .line 99
    new-instance v1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    const-wide/16 v2, 0x2d

    const-string v4, "\u63a5\u8fd1\u8fd0\u8425\u5546\u81ea\u52a8\u5207\u65ad\u65f6\u95f4\uff0c\u6700\u4e0d\u6f0f\u63a5"

    const-string v5, "\u7ecf\u9a8c 45 \u79d2"

    invoke-direct {v1, v5, v2, v3, v4}, Lcom/calltimer/app/WaitStatsAnalyzer$Row;-><init>(Ljava/lang/String;JLjava/lang/String;)V

    invoke-static {v0, v1}, Lcom/calltimer/app/WaitStatsAnalyzer;->addRowIfDistinct(Lcom/calltimer/app/WaitStatsAnalyzer$Result;Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V

    .line 101
    invoke-static {p0, v0}, Lcom/calltimer/app/WaitStatsAnalyzer;->loadCallLogRate(Landroid/content/Context;Lcom/calltimer/app/WaitStatsAnalyzer$Result;)V

    return-object v0
.end method

.method private static countOutgoing(Landroid/content/Context;JZ)I
    .locals 7

    if-eqz p3, :cond_0

    .line 136
    const-string p3, " AND duration>0"

    goto :goto_0

    :cond_0
    const-string p3, ""

    :goto_0
    const-string v0, "type=? AND date>=?"

    invoke-virtual {v0, p3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 p3, 0x2

    .line 137
    new-array v5, p3, [Ljava/lang/String;

    invoke-static {p3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p3

    const/4 v0, 0x0

    aput-object p3, v5, v0

    .line 138
    invoke-static {p1, p2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x1

    aput-object p1, v5, p2

    const/4 p1, 0x0

    .line 141
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    sget-object v2, Landroid/provider/CallLog$Calls;->CONTENT_URI:Landroid/net/Uri;

    new-array v3, p2, [Ljava/lang/String;

    const-string p0, "COUNT(*)"

    aput-object p0, v3, v0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    if-eqz p1, :cond_2

    .line 143
    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result p0

    if-eqz p0, :cond_2

    invoke-interface {p1, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p1, :cond_1

    .line 146
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    :cond_1
    return p0

    :cond_2
    if-eqz p1, :cond_4

    goto :goto_1

    :catchall_0
    move-exception p0

    if-eqz p1, :cond_3

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 147
    :cond_3
    throw p0

    :catch_0
    if-eqz p1, :cond_4

    .line 146
    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    :cond_4
    return v0
.end method

.method private static loadCallLogRate(Landroid/content/Context;Lcom/calltimer/app/WaitStatsAnalyzer$Result;)V
    .locals 6

    .line 122
    const-string v0, "android.permission.READ_CALL_LOG"

    invoke-virtual {p0, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 124
    iput-boolean v1, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->callLogAvailable:Z

    return-void

    .line 127
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const-wide v4, 0x39ef8b000L

    sub-long/2addr v2, v4

    .line 128
    invoke-static {p0, v2, v3, v1}, Lcom/calltimer/app/WaitStatsAnalyzer;->countOutgoing(Landroid/content/Context;JZ)I

    move-result v0

    iput v0, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->clTotal:I

    const/4 v0, 0x1

    .line 129
    invoke-static {p0, v2, v3, v0}, Lcom/calltimer/app/WaitStatsAnalyzer;->countOutgoing(Landroid/content/Context;JZ)I

    move-result p0

    .line 130
    iget v2, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->clTotal:I

    if-lez v2, :cond_1

    int-to-double v2, p0

    iget p0, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->clTotal:I

    int-to-double v4, p0

    div-double/2addr v2, v4

    goto :goto_0

    :cond_1
    const-wide/16 v2, 0x0

    :goto_0
    iput-wide v2, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->clAnswerRate:D

    .line 131
    iget p0, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->clTotal:I

    if-lez p0, :cond_2

    move v1, v0

    :cond_2
    iput-boolean v1, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->callLogAvailable:Z

    return-void
.end method

.method private static quantile([JD)J
    .locals 3

    .line 113
    array-length v0, p0

    int-to-double v1, v0

    mul-double/2addr p1, v1

    .line 114
    invoke-static {p1, p2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide p1

    double-to-int p1, p1

    add-int/lit8 p1, p1, -0x1

    if-gez p1, :cond_0

    const/4 p1, 0x0

    :cond_0
    if-lt p1, v0, :cond_1

    add-int/lit8 p1, v0, -0x1

    .line 117
    :cond_1
    aget-wide p0, p0, p1

    return-wide p0
.end method
