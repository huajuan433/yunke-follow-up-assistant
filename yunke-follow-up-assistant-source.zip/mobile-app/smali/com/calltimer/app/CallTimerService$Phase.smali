.class final enum Lcom/calltimer/app/CallTimerService$Phase;
.super Ljava/lang/Enum;
.source "CallTimerService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/CallTimerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "Phase"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/calltimer/app/CallTimerService$Phase;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/calltimer/app/CallTimerService$Phase;

.field public static final enum CONNECTED:Lcom/calltimer/app/CallTimerService$Phase;

.field public static final enum IDLE:Lcom/calltimer/app/CallTimerService$Phase;

.field public static final enum WAITING:Lcom/calltimer/app/CallTimerService$Phase;


# direct methods
.method private static synthetic $values()[Lcom/calltimer/app/CallTimerService$Phase;
    .locals 3

    .line 45
    sget-object v0, Lcom/calltimer/app/CallTimerService$Phase;->IDLE:Lcom/calltimer/app/CallTimerService$Phase;

    sget-object v1, Lcom/calltimer/app/CallTimerService$Phase;->WAITING:Lcom/calltimer/app/CallTimerService$Phase;

    sget-object v2, Lcom/calltimer/app/CallTimerService$Phase;->CONNECTED:Lcom/calltimer/app/CallTimerService$Phase;

    filled-new-array {v0, v1, v2}, [Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 45
    new-instance v0, Lcom/calltimer/app/CallTimerService$Phase;

    const-string v1, "IDLE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/calltimer/app/CallTimerService$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/calltimer/app/CallTimerService$Phase;->IDLE:Lcom/calltimer/app/CallTimerService$Phase;

    new-instance v0, Lcom/calltimer/app/CallTimerService$Phase;

    const-string v1, "WAITING"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/calltimer/app/CallTimerService$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/calltimer/app/CallTimerService$Phase;->WAITING:Lcom/calltimer/app/CallTimerService$Phase;

    new-instance v0, Lcom/calltimer/app/CallTimerService$Phase;

    const-string v1, "CONNECTED"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/calltimer/app/CallTimerService$Phase;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/calltimer/app/CallTimerService$Phase;->CONNECTED:Lcom/calltimer/app/CallTimerService$Phase;

    invoke-static {}, Lcom/calltimer/app/CallTimerService$Phase;->$values()[Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v0

    sput-object v0, Lcom/calltimer/app/CallTimerService$Phase;->$VALUES:[Lcom/calltimer/app/CallTimerService$Phase;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 45
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/calltimer/app/CallTimerService$Phase;
    .locals 1

    .line 45
    const-class v0, Lcom/calltimer/app/CallTimerService$Phase;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/calltimer/app/CallTimerService$Phase;

    return-object p0
.end method

.method public static values()[Lcom/calltimer/app/CallTimerService$Phase;
    .locals 1

    .line 45
    sget-object v0, Lcom/calltimer/app/CallTimerService$Phase;->$VALUES:[Lcom/calltimer/app/CallTimerService$Phase;

    invoke-virtual {v0}, [Lcom/calltimer/app/CallTimerService$Phase;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/calltimer/app/CallTimerService$Phase;

    return-object v0
.end method
