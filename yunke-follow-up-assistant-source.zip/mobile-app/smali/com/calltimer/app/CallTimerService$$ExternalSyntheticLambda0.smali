.class public final synthetic Lcom/calltimer/app/CallTimerService$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/calltimer/app/CallTimerService;


# direct methods
.method public synthetic constructor <init>(Lcom/calltimer/app/CallTimerService;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/calltimer/app/CallTimerService$$ExternalSyntheticLambda0;->f$0:Lcom/calltimer/app/CallTimerService;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$$ExternalSyntheticLambda0;->f$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->$r8$lambda$5G9EHW3q82sMWSMG5ob8K6SKPW8(Lcom/calltimer/app/CallTimerService;)V

    return-void
.end method
