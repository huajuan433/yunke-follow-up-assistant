.class public Lcom/calltimer/app/WaitStatsAnalyzer$Row;
.super Ljava/lang/Object;
.source "WaitStatsAnalyzer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/WaitStatsAnalyzer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Row"
.end annotation


# instance fields
.field public label:Ljava/lang/String;

.field public note:Ljava/lang/String;

.field public seconds:J


# direct methods
.method constructor <init>(Ljava/lang/String;JLjava/lang/String;)V
    .locals 0

    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 31
    iput-object p1, p0, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->label:Ljava/lang/String;

    .line 32
    iput-wide p2, p0, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->seconds:J

    .line 33
    iput-object p4, p0, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->note:Ljava/lang/String;

    return-void
.end method
