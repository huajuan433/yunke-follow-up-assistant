.class public final Lcom/calltimer/app/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static btn_a11y:I = 0x7f030000

.field public static btn_adopt:I = 0x7f030001

.field public static btn_autostart:I = 0x7f030002

.field public static btn_battery:I = 0x7f030003

.field public static btn_calllog:I = 0x7f030004

.field public static btn_notification:I = 0x7f030005

.field public static btn_phone:I = 0x7f030006

.field public static btn_recommend:I = 0x7f030007

.field public static et_seconds:I = 0x7f030008

.field public static ll_rows:I = 0x7f030009

.field public static sw_countdown:I = 0x7f03000a

.field public static sw_enable:I = 0x7f03000b

.field public static sw_overlay:I = 0x7f030016

.field public static sw_overlay_ontop:I = 0x7f030017

.field public static tv_a11y_state:I = 0x7f03000c

.field public static tv_autostart_state:I = 0x7f03000d

.field public static tv_battery_state:I = 0x7f03000e

.field public static tv_calllog_state:I = 0x7f03000f

.field public static tv_log:I = 0x7f030010

.field public static tv_notification_state:I = 0x7f030011

.field public static tv_phone_state:I = 0x7f030012

.field public static tv_result:I = 0x7f030013

.field public static tv_scan:I = 0x7f030014

.field public static tv_status:I = 0x7f030015


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
