.class public final Lcom/calltimer/app/YkOverlay$1;
.super Ljava/lang/Object;
.source "YkOverlay.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    invoke-static {}, Lcom/calltimer/app/YkOverlay;->hide()V

    return-void
.end method
