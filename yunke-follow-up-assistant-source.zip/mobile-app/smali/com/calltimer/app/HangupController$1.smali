.class Lcom/calltimer/app/HangupController$1;
.super Ljava/lang/Object;
.source "HangupController.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/calltimer/app/HangupController;->run(Landroid/content/Context;Ljava/lang/Runnable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$app:Landroid/content/Context;

.field final synthetic val$generation:I

.field final synthetic val$loop:[Ljava/lang/Runnable;

.field final synthetic val$main:Landroid/os/Handler;

.field final synthetic val$onComplete:Ljava/lang/Runnable;

.field final synthetic val$round:[I

.field final synthetic val$wl:Landroid/os/PowerManager$WakeLock;


# direct methods
.method constructor <init>(ILandroid/content/Context;[ILandroid/os/Handler;[Ljava/lang/Runnable;Landroid/os/PowerManager$WakeLock;Ljava/lang/Runnable;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 60
    iput p1, p0, Lcom/calltimer/app/HangupController$1;->val$generation:I

    iput-object p2, p0, Lcom/calltimer/app/HangupController$1;->val$app:Landroid/content/Context;

    iput-object p3, p0, Lcom/calltimer/app/HangupController$1;->val$round:[I

    iput-object p4, p0, Lcom/calltimer/app/HangupController$1;->val$main:Landroid/os/Handler;

    iput-object p5, p0, Lcom/calltimer/app/HangupController$1;->val$loop:[Ljava/lang/Runnable;

    iput-object p6, p0, Lcom/calltimer/app/HangupController$1;->val$wl:Landroid/os/PowerManager$WakeLock;

    iput-object p7, p0, Lcom/calltimer/app/HangupController$1;->val$onComplete:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private release()V
    .locals 1

    .line 137
    :try_start_0
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$wl:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$wl:Landroid/os/PowerManager$WakeLock;

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 139
    :catch_0
    :cond_0
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$onComplete:Ljava/lang/Runnable;

    if-eqz v0, :cond_1

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_1
    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    .line 64
    iget v0, p0, Lcom/calltimer/app/HangupController$1;->val$generation:I

    invoke-static {}, Lcom/calltimer/app/HangupController;->-$$Nest$sfgetsGeneration()I

    move-result v1

    const-string v2, ")"

    const-string v3, "HangupController"

    if-eq v0, v1, :cond_0

    .line 65
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "hangup generation stale, abort (gen="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lcom/calltimer/app/HangupController$1;->val$generation:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", current="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-static {}, Lcom/calltimer/app/HangupController;->-$$Nest$sfgetsGeneration()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 67
    const-string v0, "hangup flow aborted (stale generation)"

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 68
    invoke-direct {p0}, Lcom/calltimer/app/HangupController$1;->release()V

    return-void

    .line 71
    :cond_0
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$app:Landroid/content/Context;

    const-string v1, "phone"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    const/4 v1, 0x0

    .line 74
    :try_start_0
    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getCallState()I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    .line 76
    const-string v4, "getCallState failed"

    invoke-static {v3, v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move v0, v1

    :goto_0
    if-nez v0, :cond_1

    .line 80
    invoke-direct {p0}, Lcom/calltimer/app/HangupController$1;->release()V

    return-void

    .line 84
    :cond_1
    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "hangup round "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v5, p0, Lcom/calltimer/app/HangupController$1;->val$round:[I

    aget v5, v5, v1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, ", callState="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 87
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lcom/calltimer/app/CallSignals;->micActive(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "[yk] mic active but ignored (false-positive during ringing)"

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 95
    :cond_2
    invoke-static {}, Lcom/calltimer/app/HangupReporter;->ykGetReason()Ljava/lang/String;

    move-result-object v0

    const-string v4, "pc"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    const-string v0, "[yk] v77 pc hangup cmd: skip connected guard"

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    :cond_3
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->scanNow()Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    move-result-object v0

    if-eqz v0, :cond_4

    .line 96
    iget-boolean v4, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    if-eqz v4, :cond_4

    .line 97
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "call connected right before hangup, abort: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 98
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "HANGUP aborted, connected evidence: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 99
    invoke-direct {p0}, Lcom/calltimer/app/HangupController$1;->release()V

    return-void

    .line 103
    :cond_4
    :goto_1
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lcom/calltimer/app/EndCaller;->endCall(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-static {}, Lcom/calltimer/app/HangupReporter;->report()V

    :cond_5
    const/4 v4, 0x1

    if-eqz v0, :cond_6

    .line 105
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "hangup requested via Telecom API (round "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/calltimer/app/HangupController$1;->val$round:[I

    aget v3, v3, v1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    goto :goto_4

    .line 107
    :cond_6
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$app:Landroid/content/Context;

    const-string v2, "android.permission.ANSWER_PHONE_CALLS"

    invoke-virtual {v0, v2}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_7

    move v0, v4

    goto :goto_2

    :cond_7
    move v0, v1

    :goto_2
    if-nez v0, :cond_8

    .line 109
    const-string v2, "no ANSWER_PHONE_CALLS permission"

    invoke-static {v3, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 110
    :cond_8
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v5, "Telecom API failed (perm="

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "), fallback unlock + accessibility tap"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 113
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$round:[I

    aget v0, v0, v1

    if-eqz v0, :cond_9

    const/4 v2, 0x2

    if-ne v0, v2, :cond_a

    .line 115
    :cond_9
    :try_start_1
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->swipeUpUnlock()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception v0

    .line 117
    const-string v2, "swipe unlock failed"

    invoke-static {v3, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 121
    :cond_a
    :goto_3
    :try_start_2
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->requestHangup()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_4

    :catchall_2
    move-exception v0

    .line 123
    const-string v2, "accessibility hangup failed"

    invoke-static {v3, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 127
    :goto_4
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$round:[I

    aget v2, v0, v1

    add-int/2addr v2, v4

    aput v2, v0, v1

    const/16 v0, 0x11

    if-ge v2, v0, :cond_b

    .line 129
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$main:Landroid/os/Handler;

    iget-object v2, p0, Lcom/calltimer/app/HangupController$1;->val$loop:[Ljava/lang/Runnable;

    aget-object v1, v2, v1

    const-wide/16 v2, 0x15e

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_5

    .line 131
    :cond_b
    :try_start_3
    iget-object v0, p0, Lcom/calltimer/app/HangupController$1;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lcom/calltimer/app/EndCallApi29;->endCallTelecom(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_c

    invoke-static {}, Lcom/calltimer/app/HangupReporter;->report()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    :catchall_3
    :cond_c
    invoke-direct {p0}, Lcom/calltimer/app/HangupController$1;->release()V

    :goto_5
    return-void
.end method
