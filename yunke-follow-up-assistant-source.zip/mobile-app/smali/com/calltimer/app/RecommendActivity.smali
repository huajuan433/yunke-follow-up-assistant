.class public Lcom/calltimer/app/RecommendActivity;
.super Landroid/app/Activity;
.source "RecommendActivity.java"


# static fields
.field private static final REQ_CALL_LOG:I = 0xc8


# instance fields
.field private btnAdopt:Landroid/widget/Button;

.field private last:Lcom/calltimer/app/WaitStatsAnalyzer$Result;

.field private llRows:Landroid/widget/LinearLayout;

.field private tvResult:Landroid/widget/TextView;


# direct methods
.method public static synthetic $r8$lambda$_qrFWoEPhkNV8jFFzGYcwFbT8nY(Lcom/calltimer/app/RecommendActivity;Lcom/calltimer/app/WaitStatsAnalyzer$Row;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/calltimer/app/RecommendActivity;->lambda$addRow$0(Lcom/calltimer/app/WaitStatsAnalyzer$Row;Landroid/view/View;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 22
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private addRow(Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V
    .locals 9

    .line 109
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x0

    .line 110
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    .line 111
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v2, 0xc

    .line 112
    invoke-direct {p0, v2}, Lcom/calltimer/app/RecommendActivity;->dp(I)I

    move-result v2

    .line 113
    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 114
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v3, 0x6

    .line 116
    invoke-direct {p0, v3}, Lcom/calltimer/app/RecommendActivity;->dp(I)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 117
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v2, -0xa0a0b

    .line 118
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 119
    new-instance v2, Landroid/util/TypedValue;

    invoke-direct {v2}, Landroid/util/TypedValue;-><init>()V

    .line 120
    invoke-virtual {p0}, Lcom/calltimer/app/RecommendActivity;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v3

    const v5, 0x101030e

    const/4 v6, 0x1

    invoke-virtual {v3, v5, v2, v6}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    .line 121
    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 123
    :try_start_0
    iget v2, v2, Landroid/util/TypedValue;->resourceId:I

    invoke-virtual {p0, v2}, Lcom/calltimer/app/RecommendActivity;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 127
    :catchall_0
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 128
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v3, v1, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v3, 0x41500000    # 13.0f

    .line 130
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 131
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->label:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, "\u3000"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-wide v7, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->seconds:J

    invoke-virtual {v4, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " \u79d2\n"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->note:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 132
    iget-object v4, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->label:Ljava/lang/String;

    const-string v5, "\u2605"

    invoke-virtual {v4, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    const v5, -0x39d7d8

    if-eqz v4, :cond_0

    .line 134
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 135
    invoke-virtual {v2}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    move-result-object v7

    invoke-virtual {v2, v7, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_0

    :cond_0
    const v6, -0xdededf

    .line 137
    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 140
    :goto_0
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 141
    const-string v7, "\u91c7\u7528 \u203a"

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 142
    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setTextSize(F)V

    if-eqz v4, :cond_1

    goto :goto_1

    :cond_1
    const v5, -0x9e9e9f

    .line 143
    :goto_1
    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v3, 0xa

    .line 144
    invoke-direct {p0, v3}, Lcom/calltimer/app/RecommendActivity;->dp(I)I

    move-result v3

    invoke-virtual {v6, v3, v1, v1, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 146
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 147
    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 148
    new-instance v1, Lcom/calltimer/app/RecommendActivity$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lcom/calltimer/app/RecommendActivity$$ExternalSyntheticLambda0;-><init>(Lcom/calltimer/app/RecommendActivity;Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 149
    iget-object p1, p0, Lcom/calltimer/app/RecommendActivity;->llRows:Landroid/widget/LinearLayout;

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private adopt(J)V
    .locals 2

    long-to-int v0, p1

    .line 153
    invoke-static {p0, v0}, Lcom/calltimer/app/Prefs;->setSeconds(Landroid/content/Context;I)V

    .line 154
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u5df2\u91c7\u7528 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, " \u79d2"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 155
    invoke-virtual {p0}, Lcom/calltimer/app/RecommendActivity;->finish()V

    return-void
.end method

.method private dp(I)I
    .locals 1

    int-to-float p1, p1

    .line 159
    invoke-virtual {p0}, Lcom/calltimer/app/RecommendActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method private synthetic lambda$addRow$0(Lcom/calltimer/app/WaitStatsAnalyzer$Row;Landroid/view/View;)V
    .locals 0

    .line 148
    iget-wide p1, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Row;->seconds:J

    invoke-direct {p0, p1, p2}, Lcom/calltimer/app/RecommendActivity;->adopt(J)V

    return-void
.end method

.method private render()V
    .locals 8

    .line 64
    invoke-virtual {p0}, Lcom/calltimer/app/RecommendActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/WaitStatsAnalyzer;->analyze(Landroid/content/Context;)Lcom/calltimer/app/WaitStatsAnalyzer$Result;

    move-result-object v0

    .line 65
    iput-object v0, p0, Lcom/calltimer/app/RecommendActivity;->last:Lcom/calltimer/app/WaitStatsAnalyzer$Result;

    .line 66
    iget-object v1, p0, Lcom/calltimer/app/RecommendActivity;->llRows:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 68
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 69
    iget v2, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->total:I

    if-nez v2, :cond_0

    .line 70
    const-string v2, "\u8fd8\u6ca1\u6709\u91c7\u96c6\u5230\u53bb\u7535\u6837\u672c\u3002\n\n\u8bf7\u5148\u6309\u9996\u9875\u8bf4\u660e\u5b8c\u6210\u8bbe\u7f6e\uff08\u5c24\u5176\u662f\u2464\u65e0\u969c\u788d\uff09\uff0c\u542f\u7528\u670d\u52a1\u540e\u6b63\u5e38\u6253\u7535\u8bdd\uff1a\n\u00b7 \u6bcf\u901a\u53bb\u7535\u4ece\u62e8\u51fa\u5230\u63a5\u901a\u7684\u7b49\u5f85\u79d2\u6570\u4f1a\u81ea\u52a8\u8bb0\u5f55\n\u00b7 \u6ca1\u4eba\u63a5\u88ab\u81ea\u52a8\u6302\u65ad\u7684\u4e5f\u4f1a\u8bb0\u5f55\n\n\u79ef\u7d2f 10 \u901a\u4ee5\u4e0a\u63a5\u901a\u7684\u7535\u8bdd\u540e\uff0c\u63a8\u8350\u503c\u4f1a\u8d34\u5408\u4f60\u7684\u5b9e\u9645\u63a5\u901a\u89c4\u5f8b\u3002\n\u5f53\u524d\u53ef\u5148\u91c7\u7528\u7ecf\u9a8c\u503c "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    iget-wide v2, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u79d2\uff08\u7ea6 5 \u58f0\u56de\u94c3\u97f3\uff09\u3002"

    .line 76
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_1

    .line 78
    :cond_0
    const-string v2, "\u5df2\u91c7\u96c6\u53bb\u7535 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->total:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u901a\uff1a\u63a5\u901a "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->connectedCount:I

    .line 79
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u901a\uff0c\u672a\u63a5 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->missedCount:I

    .line 80
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u901a\uff0c\u63a5\u901a\u7387 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->answerRate:D

    const-wide/high16 v6, 0x4059000000000000L    # 100.0

    mul-double/2addr v4, v6

    .line 81
    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "%\n"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    iget-boolean v2, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->enoughSamples:Z

    if-eqz v2, :cond_1

    .line 83
    const-string v2, "\u63a5\u901a\u7b49\u5f85\uff1a\u4e2d\u4f4d "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->medianWait:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " \u79d2\uff0cP90 "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->p90Wait:J

    .line 84
    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " \u79d2\uff0c\u5e73\u5747 "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->meanWait:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " \u79d2\n\n\u2605 \u63a8\u8350\u7b49\u5f85 "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    iget-wide v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " \u79d2\uff1a90% \u4f1a\u63a5\u7684\u7535\u8bdd\u5728\u8fd9\u4e2a\u65f6\u95f4\u5185\u63a5\u8d77\uff0c\u8d85\u65f6\u672a\u63a5\u81ea\u52a8\u6302\u65ad\n"

    .line 86
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_0

    .line 88
    :cond_1
    const-string v2, "\u5df2\u63a5\u901a\u6837\u672c "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->connectedCount:I

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " \u901a\uff08\u4e0d\u8db3 10 \u901a\uff09\uff0c\u5148\u7528\u7ecf\u9a8c\u503c "

    .line 89
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " \u79d2\uff0c\u7ee7\u7eed\u4f7f\u7528\u540e\u81ea\u52a8\u53d8\u51c6\n"

    .line 90
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 92
    :goto_0
    iget-boolean v2, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->callLogAvailable:Z

    if-eqz v2, :cond_2

    .line 93
    const-string v2, "\n\u901a\u8bdd\u8bb0\u5f55\u53e3\u5f84\uff1a\u8fd1\u534a\u5e74\u53bb\u7535 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v4, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->clTotal:I

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    .line 94
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-wide v3, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->clAnswerRate:D

    mul-double/2addr v3, v6

    invoke-static {v3, v4}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "%"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    :cond_2
    const-string v2, "\n\n\u70b9\u51fb\u4e0b\u65b9\u4efb\u4e00\u884c\u5373\u53ef\u91c7\u7528\uff1a"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    :goto_1
    iget-object v2, p0, Lcom/calltimer/app/RecommendActivity;->tvResult:Landroid/widget/TextView;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 100
    iget-object v1, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->rows:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/calltimer/app/WaitStatsAnalyzer$Row;

    .line 101
    invoke-direct {p0, v2}, Lcom/calltimer/app/RecommendActivity;->addRow(Lcom/calltimer/app/WaitStatsAnalyzer$Row;)V

    goto :goto_2

    .line 104
    :cond_3
    iget-object v1, p0, Lcom/calltimer/app/RecommendActivity;->btnAdopt:Landroid/widget/Button;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "\u91c7\u7528\u63a8\u8350\u503c "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v3, v0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " \u79d2\u5e76\u8fd4\u56de"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 105
    iget-object v0, p0, Lcom/calltimer/app/RecommendActivity;->btnAdopt:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    return-void
.end method


# virtual methods
.method public onAdoptOptimal(Landroid/view/View;)V
    .locals 2

    .line 50
    iget-object p1, p0, Lcom/calltimer/app/RecommendActivity;->last:Lcom/calltimer/app/WaitStatsAnalyzer$Result;

    if-eqz p1, :cond_0

    iget-wide v0, p1, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->recommended:J

    invoke-direct {p0, v0, v1}, Lcom/calltimer/app/RecommendActivity;->adopt(J)V

    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    .line 33
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 34
    sget p1, Lcom/calltimer/app/R$layout;->activity_recommend:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/RecommendActivity;->setContentView(I)V

    .line 35
    const-string p1, "\u667a\u80fd\u63a8\u8350\u7b49\u5f85\u79d2\u6570"

    invoke-virtual {p0, p1}, Lcom/calltimer/app/RecommendActivity;->setTitle(Ljava/lang/CharSequence;)V

    .line 37
    sget p1, Lcom/calltimer/app/R$id;->tv_result:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/RecommendActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iput-object p1, p0, Lcom/calltimer/app/RecommendActivity;->tvResult:Landroid/widget/TextView;

    .line 38
    sget p1, Lcom/calltimer/app/R$id;->ll_rows:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/RecommendActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/LinearLayout;

    iput-object p1, p0, Lcom/calltimer/app/RecommendActivity;->llRows:Landroid/widget/LinearLayout;

    .line 39
    sget p1, Lcom/calltimer/app/R$id;->btn_adopt:I

    invoke-virtual {p0, p1}, Lcom/calltimer/app/RecommendActivity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/Button;

    iput-object p1, p0, Lcom/calltimer/app/RecommendActivity;->btnAdopt:Landroid/widget/Button;

    .line 40
    invoke-direct {p0}, Lcom/calltimer/app/RecommendActivity;->render()V

    return-void
.end method

.method public onRequestCallLog(Landroid/view/View;)V
    .locals 2

    .line 54
    const-string p1, "android.permission.READ_CALL_LOG"

    invoke-virtual {p0, p1}, Lcom/calltimer/app/RecommendActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    .line 56
    new-array v0, v0, [Ljava/lang/String;

    aput-object p1, v0, v1

    const/16 p1, 0xc8

    invoke-virtual {p0, v0, p1}, Lcom/calltimer/app/RecommendActivity;->requestPermissions([Ljava/lang/String;I)V

    goto :goto_0

    .line 58
    :cond_0
    invoke-direct {p0}, Lcom/calltimer/app/RecommendActivity;->render()V

    .line 59
    const-string p1, "\u5df2\u6388\u6743"

    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 0

    .line 165
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/16 p2, 0xc8

    if-ne p1, p2, :cond_0

    .line 167
    invoke-direct {p0}, Lcom/calltimer/app/RecommendActivity;->render()V

    :cond_0
    return-void
.end method

.method protected onResume()V
    .locals 1

    .line 45
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 46
    iget-object v0, p0, Lcom/calltimer/app/RecommendActivity;->last:Lcom/calltimer/app/WaitStatsAnalyzer$Result;

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/calltimer/app/RecommendActivity;->render()V

    :cond_0
    return-void
.end method
