.class public Lcom/calltimer/app/WaitStatsAnalyzer$Result;
.super Ljava/lang/Object;
.source "WaitStatsAnalyzer.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/WaitStatsAnalyzer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Result"
.end annotation


# instance fields
.field public answerRate:D

.field public callLogAvailable:Z

.field public clAnswerRate:D

.field public clTotal:I

.field public connectedCount:I

.field public enoughSamples:Z

.field public meanWait:J

.field public medianWait:J

.field public missedCount:I

.field public p80Wait:J

.field public p90Wait:J

.field public p95Wait:J

.field public recommended:J

.field public final rows:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/calltimer/app/WaitStatsAnalyzer$Row;",
            ">;"
        }
    .end annotation
.end field

.field public total:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 37
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 49
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/calltimer/app/WaitStatsAnalyzer$Result;->rows:Ljava/util/List;

    return-void
.end method
