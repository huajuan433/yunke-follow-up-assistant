.class public final Lcom/calltimer/app/YkOverlay$2;
.super Ljava/lang/Object;
.source "YkOverlay.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Prefs;->getSeconds(Landroid/content/Context;)I

    move-result v1

    add-int/lit8 v1, v1, -0x5

    const/4 v2, 0x5

    if-ge v1, v2, :cond_0

    const/4 v1, 0x5

    :cond_0
    invoke-static {v0, v1}, Lcom/calltimer/app/Prefs;->setSeconds(Landroid/content/Context;I)V

    invoke-static {}, Lcom/calltimer/app/YkOverlay;->refresh()V

    return-void
.end method
