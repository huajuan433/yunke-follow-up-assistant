.class Lcom/calltimer/app/Api31TelephonyCallback;
.super Landroid/telephony/TelephonyCallback;
.source "Api31TelephonyCallback.java"

# interfaces
.implements Landroid/telephony/TelephonyCallback$CallStateListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;
    }
.end annotation


# instance fields
.field private final handler:Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;


# direct methods
.method private constructor <init>(Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;)V
    .locals 0

    .line 22
    invoke-direct {p0}, Landroid/telephony/TelephonyCallback;-><init>()V

    .line 23
    iput-object p1, p0, Lcom/calltimer/app/Api31TelephonyCallback;->handler:Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;

    return-void
.end method

.method static register(Landroid/telephony/TelephonyManager;Ljava/util/concurrent/Executor;Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;)Ljava/lang/Object;
    .locals 1

    .line 33
    new-instance v0, Lcom/calltimer/app/Api31TelephonyCallback;

    invoke-direct {v0, p2}, Lcom/calltimer/app/Api31TelephonyCallback;-><init>(Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;)V

    .line 34
    invoke-virtual {p0, p1, v0}, Landroid/telephony/TelephonyManager;->registerTelephonyCallback(Ljava/util/concurrent/Executor;Landroid/telephony/TelephonyCallback;)V

    return-object v0
.end method

.method static unregister(Landroid/telephony/TelephonyManager;Ljava/lang/Object;)V
    .locals 1

    .line 39
    instance-of v0, p1, Lcom/calltimer/app/Api31TelephonyCallback;

    if-eqz v0, :cond_0

    .line 40
    check-cast p1, Lcom/calltimer/app/Api31TelephonyCallback;

    invoke-virtual {p0, p1}, Landroid/telephony/TelephonyManager;->unregisterTelephonyCallback(Landroid/telephony/TelephonyCallback;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public onCallStateChanged(I)V
    .locals 1

    .line 28
    iget-object v0, p0, Lcom/calltimer/app/Api31TelephonyCallback;->handler:Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, Lcom/calltimer/app/Api31TelephonyCallback$CallStateHandler;->onState(I)V

    :cond_0
    return-void
.end method
