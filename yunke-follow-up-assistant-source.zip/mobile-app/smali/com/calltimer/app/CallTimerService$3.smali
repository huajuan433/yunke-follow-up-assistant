.class Lcom/calltimer/app/CallTimerService$3;
.super Ljava/lang/Object;
.source "CallTimerService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/CallTimerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/CallTimerService;


# direct methods
.method constructor <init>(Lcom/calltimer/app/CallTimerService;)V
    .locals 0

    .line 104
    iput-object p1, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    .line 107
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmPhase(Lcom/calltimer/app/CallTimerService;)Lcom/calltimer/app/CallTimerService$Phase;

    move-result-object v0

    sget-object v1, Lcom/calltimer/app/CallTimerService$Phase;->WAITING:Lcom/calltimer/app/CallTimerService$Phase;

    if-eq v0, v1, :cond_0

    return-void

    .line 109
    :cond_0
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmPollCount(Lcom/calltimer/app/CallTimerService;)I

    move-result v0

    const/4 v1, 0x1

    and-int/2addr v0, v1

    if-nez v0, :cond_1

    .line 110
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmStartElapsed(Lcom/calltimer/app/CallTimerService;)J

    move-result-wide v4

    sub-long/2addr v2, v4

    long-to-double v2, v2

    const-wide v4, 0x408f400000000000L    # 1000.0

    div-double/2addr v2, v4

    .line 111
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, "t=%.1f "

    invoke-static {v4, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v2, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    .line 112
    invoke-static {v2}, Lcom/calltimer/app/CallSignals;->sample(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 111
    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->sample(Ljava/lang/String;)V

    .line 114
    :cond_1
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmPollCount(Lcom/calltimer/app/CallTimerService;)I

    move-result v2

    add-int/2addr v2, v1

    invoke-static {v0, v2}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fputmPollCount(Lcom/calltimer/app/CallTimerService;I)V

    .line 117
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallSignals;->micActive(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_3

    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->scanNow()Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-boolean v3, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    if-eqz v3, :cond_2

    const-string v0, "CONNECTED (mic active)"

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0, v2}, Lcom/calltimer/app/CallTimerService;->-$$Nest$menterConnected(Lcom/calltimer/app/CallTimerService;Z)V

    return-void

    :cond_2
    const-string v0, "[yk] poll: mic active but scan NOT connected, keep waiting"

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 123
    :cond_3
    invoke-static {}, Lcom/calltimer/app/HangupAccessibilityService;->scanNow()Lcom/calltimer/app/HangupAccessibilityService$ScanResult;

    move-result-object v0

    if-eqz v0, :cond_7

    .line 125
    iget-boolean v3, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->callUiVisible:Z

    if-eqz v3, :cond_4

    iget-object v3, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v3, v1}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fputmEverCallUi(Lcom/calltimer/app/CallTimerService;Z)V

    .line 126
    :cond_4
    iget-boolean v1, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->dialing:Z

    if-eqz v1, :cond_5

    iget-object v1, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-static {v1, v3, v4}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fputmLastDialingElapsed(Lcom/calltimer/app/CallTimerService;J)V

    .line 127
    :cond_5
    iget-boolean v1, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->busy:Z

    if-eqz v1, :cond_6

    const-string v0, "[yk] busy/off detected, hangup now"

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$mfinalizeHangup(Lcom/calltimer/app/CallTimerService;)V

    return-void

    :cond_6
    iget-boolean v1, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->connected:Z

    if-eqz v1, :cond_7

    .line 128
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "connected detected: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->reason:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " / "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v3, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->hitText:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "CallTimerService"

    invoke-static {v3, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 129
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "CONNECTED (timer/text): "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, Lcom/calltimer/app/HangupAccessibilityService$ScanResult;->reason:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/calltimer/app/Diagnostic;->log(Ljava/lang/String;)V

    .line 130
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0, v2}, Lcom/calltimer/app/CallTimerService;->-$$Nest$menterConnected(Lcom/calltimer/app/CallTimerService;Z)V

    return-void

    .line 134
    :cond_7
    iget-object v0, p0, Lcom/calltimer/app/CallTimerService$3;->this$0:Lcom/calltimer/app/CallTimerService;

    invoke-static {v0}, Lcom/calltimer/app/CallTimerService;->-$$Nest$fgetmMain(Lcom/calltimer/app/CallTimerService;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x64

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
