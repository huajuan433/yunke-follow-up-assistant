.class public final synthetic Lcom/calltimer/app/AlarmReceiver$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/content/BroadcastReceiver$PendingResult;


# direct methods
.method public synthetic constructor <init>(Landroid/content/BroadcastReceiver$PendingResult;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/calltimer/app/AlarmReceiver$$ExternalSyntheticLambda0;->f$0:Landroid/content/BroadcastReceiver$PendingResult;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/calltimer/app/AlarmReceiver$$ExternalSyntheticLambda0;->f$0:Landroid/content/BroadcastReceiver$PendingResult;

    invoke-static {v0}, Lcom/calltimer/app/AlarmReceiver;->$r8$lambda$8wZ3QE6vvtlw1qzQ0KiyZF_LRHs(Landroid/content/BroadcastReceiver$PendingResult;)V

    return-void
.end method
