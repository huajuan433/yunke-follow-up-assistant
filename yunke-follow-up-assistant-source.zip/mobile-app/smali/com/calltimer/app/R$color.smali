.class public final Lcom/calltimer/app/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/calltimer/app/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static accent:I = 0x7f010000

.field public static card_bg:I = 0x7f010001

.field public static icon_bg:I = 0x7f010002

.field public static primary:I = 0x7f010003

.field public static primary_dark:I = 0x7f010004

.field public static state_green:I = 0x7f010005

.field public static state_red:I = 0x7f010006

.field public static text_main:I = 0x7f010007

.field public static text_sub:I = 0x7f010008

.field public static white:I = 0x7f010009


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
