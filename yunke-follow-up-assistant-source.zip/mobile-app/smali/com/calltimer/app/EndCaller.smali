.class public final Lcom/calltimer/app/EndCaller;
.super Ljava/lang/Object;
.source "EndCaller.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static endCall(Landroid/content/Context;)Z
    .locals 2

    .line 14
    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-lt v0, v1, :cond_0

    .line 15
    invoke-static {p0}, Lcom/calltimer/app/EndCallApi29;->endCall(Landroid/content/Context;)Z

    move-result p0

    return p0

    .line 17
    :cond_0
    invoke-static {p0}, Lcom/calltimer/app/EndCallLegacy;->endCall(Landroid/content/Context;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p0

    :catchall_0
    const/4 p0, 0x0

    return p0
.end method
