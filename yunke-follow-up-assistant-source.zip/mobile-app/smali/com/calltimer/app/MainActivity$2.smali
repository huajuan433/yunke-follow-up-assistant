.class Lcom/calltimer/app/MainActivity$2;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/calltimer/app/MainActivity;->onCreate(Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/calltimer/app/MainActivity;


# direct methods
.method constructor <init>(Lcom/calltimer/app/MainActivity;)V
    .locals 0

    .line 67
    iput-object p1, p0, Lcom/calltimer/app/MainActivity$2;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 3

    .line 72
    iget-object p1, p0, Lcom/calltimer/app/MainActivity$2;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-static {p1}, Lcom/calltimer/app/MainActivity;->-$$Nest$fgetmain(Lcom/calltimer/app/MainActivity;)Landroid/os/Handler;

    move-result-object p1

    iget-object v0, p0, Lcom/calltimer/app/MainActivity$2;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-static {v0}, Lcom/calltimer/app/MainActivity;->-$$Nest$fgetsaveSeconds(Lcom/calltimer/app/MainActivity;)Ljava/lang/Runnable;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 73
    iget-object p1, p0, Lcom/calltimer/app/MainActivity$2;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-static {p1}, Lcom/calltimer/app/MainActivity;->-$$Nest$fgetmain(Lcom/calltimer/app/MainActivity;)Landroid/os/Handler;

    move-result-object p1

    iget-object v0, p0, Lcom/calltimer/app/MainActivity$2;->this$0:Lcom/calltimer/app/MainActivity;

    invoke-static {v0}, Lcom/calltimer/app/MainActivity;->-$$Nest$fgetsaveSeconds(Lcom/calltimer/app/MainActivity;)Ljava/lang/Runnable;

    move-result-object v0

    const-wide/16 v1, 0x190

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method
